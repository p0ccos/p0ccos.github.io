package br.edu.unifei.ecot12.roca;

public class Temperatura extends Variacao {
    private int graus;

    public int getGraus() {
        return graus;
    }

    public void setGraus(int v) {
        notificar(v - graus);
        graus = v;
    }


}
