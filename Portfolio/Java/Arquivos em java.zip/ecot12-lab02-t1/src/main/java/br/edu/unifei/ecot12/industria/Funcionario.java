package br.edu.unifei.ecot12.industria;

import java.util.ArrayList;
import java.util.List;

import javax.xml.crypto.Data;

public class Funcionario {
    private int matricula;
    private String nome;
    private Data admssao;
    private float salario;
    private Departamento departamento;
    private List<Projeto> projetos = new ArrayList<Projeto>();
    public int getMatricula() {
        return matricula;
    }
    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public Data getAdmssao() {
        return admssao;
    }
    public void setAdmssao(Data admssao) {
        this.admssao = admssao;
    }
    public float getSalario() {
        return salario;
    }
    public void setSalario(float salario) {
        this.salario = salario;
    }
    public Departamento getDepartamento() {
        return departamento;
    }
    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }
    public List<Projeto> getProjetos() {
        return projetos;
    }
    public void setProjetos(List<Projeto> projetos) {
        this.projetos = projetos;
    }


}
