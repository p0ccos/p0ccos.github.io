package br.edu.unifei.ecot12.fight;

public class Ryu extends Personagem{
    private int defesa=100;
    private int vitalidade=100;
    private int forca=100;

    public void hadouken(){
        chamarBater();
    }

    public int getDefesa() {
        return defesa;
    }

    public void setDefesa(int defesa) {
        this.defesa = defesa;
    }

    public int getVitalidade() {
        return vitalidade;
    }

    public void setVitalidade(int vitalidade) {
        this.vitalidade = vitalidade;
    }

    public int getForca() {
        return forca;
    }

    public void setForca(int forca) {
        this.forca = forca;
    }
    
}
