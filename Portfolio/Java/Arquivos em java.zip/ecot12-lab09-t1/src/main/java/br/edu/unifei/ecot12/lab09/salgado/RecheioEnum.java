package br.edu.unifei.ecot12.lab09.salgado;

public enum RecheioEnum {
    CARNE_SECA,
    FRANGO,
    CALABRESA
}
