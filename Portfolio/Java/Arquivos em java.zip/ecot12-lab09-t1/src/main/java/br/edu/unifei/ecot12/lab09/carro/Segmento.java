package br.edu.unifei.ecot12.lab09.carro;

public interface Segmento {
    
    public void construirMotor(Carro c);

}
