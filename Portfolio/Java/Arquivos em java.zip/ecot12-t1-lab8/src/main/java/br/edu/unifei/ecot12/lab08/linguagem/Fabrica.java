package br.edu.unifei.ecot12.lab08.linguagem;

import java.util.HashMap;

public class Fabrica{

    private HashMap <String,Palavra> compartilha= new HashMap<String,Palavra>();

    public Termo getTermo(String s){
        try {
            double d= Double.parseDouble(s);
            Numero n = new Numero();
            n.setValor(d);
            return n;
        } catch (Exception e) {
           Palavra p = compartilha.get(s);
           if (p==null){
            p = new Palavra();
            p.setCaracteres(s);
            compartilha.put(s,p);
           }
           return p;
        }
        
    }

    public HashMap<String, Palavra> getCompartilha() {
        return compartilha;
    }

    public void setCompartilha(HashMap<String, Palavra> compartilha) {
        this.compartilha = compartilha;
    }
    
}
