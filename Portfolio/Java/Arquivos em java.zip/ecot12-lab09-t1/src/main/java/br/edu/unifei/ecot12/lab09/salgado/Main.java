package br.edu.unifei.ecot12.lab09.salgado;

public class Main {
    public static void main(String[] args) {
        
    }

}
