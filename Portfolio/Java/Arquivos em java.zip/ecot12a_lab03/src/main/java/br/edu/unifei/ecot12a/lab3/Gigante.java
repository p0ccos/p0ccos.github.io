package br.edu.unifei.ecot12a.lab3;

public class Gigante extends Divindade {
    private boolean restituirVida;

    public boolean isRestituirVida() {
        return restituirVida;
    }

    public void setRestituirVida(boolean restituirVida) {
        this.restituirVida = restituirVida;
    }

    
}
