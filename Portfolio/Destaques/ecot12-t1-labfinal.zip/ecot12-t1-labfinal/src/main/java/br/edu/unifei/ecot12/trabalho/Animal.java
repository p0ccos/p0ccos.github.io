package br.edu.unifei.ecot12.trabalho;

public abstract class Animal extends Ser {
    private int patas;
    
    public int getPatas() {
        return patas;
    }
    public void setPatas(int patas) {
        this.patas = patas;
    }
    public Animal(String nome, int idade){
        super(nome,idade,new EstadoAnimal(),true);
    }
    
}
