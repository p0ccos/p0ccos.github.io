package br.edu.unifei.ecot12.trabalho;

public class Crocodilo extends Animal {

    private double tamanhoCauda;

    public double getTamanhoCauda() {
        return tamanhoCauda;
    }

    public void setTamanhoCauda(double tamanhoCauda) {
        this.tamanhoCauda = tamanhoCauda;
    }

    public Crocodilo(String nome){
        super(nome,10);
        
    }
    
}
