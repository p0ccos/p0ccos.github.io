package br.edu.unifei.ecot12a.lab3;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Fato {
    private Calendar data;
    private String descricao;
    private String tipo;

    private Humano autor;
    private List<Humano> envolvem = new ArrayList<Humano>();
//dependencia
    private Ministerio ministerio;

    public Fato(Ministerio ministerio){
        this.ministerio = ministerio;
    }

    public Calendar getData() {
        return data;
    }
    public void setData(Calendar data) {
        this.data = data;
    }
    public String getDescricao() {
        return descricao;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public Humano getAutor() {
        return autor;
    }
    public void setAutor(Humano autor) {
        this.autor = autor;
    }
    public List<Humano> getEnvolvem() {
        return envolvem;
    }
    public void setEnvolvem(List<Humano> envolvem) {
        this.envolvem = envolvem;
    }

    public Ministerio getMinisterio() {
        return ministerio;
    }

    public void setMinisterio(Ministerio ministerio) {
        this.ministerio = ministerio;
    }
   

    
    

}
