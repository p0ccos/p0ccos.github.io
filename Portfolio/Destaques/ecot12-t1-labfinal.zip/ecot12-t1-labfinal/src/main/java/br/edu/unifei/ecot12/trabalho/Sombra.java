package br.edu.unifei.ecot12.trabalho;

public class Sombra extends Ser {
    private Ser capturado;
    private Humano invoca;
    private Humano desfaz;

    public void captura(Ser ser){
        ser.setLivre(false);
    }

    public Humano getDesfaz() {
        return desfaz;
    }

    public void setDesfaz(Humano desfaz) {
        this.desfaz = desfaz;
    }

    
    public Ser getCapturado() {
        return capturado;
    }

    public void setCapturado(Ser capturado) {
        this.capturado = capturado;
    }

    public Humano getInvoca() {
        return invoca;
    }

    public void setInvoca(Humano invoca) {
        this.invoca = invoca;
    }

    public Sombra(){
        super("Demônio das sombras", 10000, new EstadoSombra(), false);
    }
    
}//se sombra == null, livre is true.