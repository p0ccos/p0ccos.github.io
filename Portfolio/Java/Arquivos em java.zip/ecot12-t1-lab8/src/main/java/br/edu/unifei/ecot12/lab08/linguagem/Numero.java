package br.edu.unifei.ecot12.lab08.linguagem;

public class Numero implements Termo{

    private double valor;
    public double getValor() {
        return valor;
    }
    public void setValor(double valor) {
        this.valor = valor;
    }
    protected Numero(){}
    

}
