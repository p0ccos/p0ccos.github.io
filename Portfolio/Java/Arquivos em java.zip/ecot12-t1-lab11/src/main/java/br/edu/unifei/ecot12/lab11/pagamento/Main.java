package br.edu.unifei.ecot12.lab11.pagamento;

public class Main {

    public static void main(String[] args) {
        CPD c = new CPD();
        c.getComandos().add(new Descontar(new Cheque()));
        c.getComandos().add(new EmAtraso(new Boleto()));
        c.getComandos().add(new Descontar(new Cheque()));
        c.getComandos().add(new SemAtraso(new Boleto()));
        c.getComandos().add(new Descontar(new Cheque()));
        c.processar();
    }
}
