package br.edu.unifei.ecot12a.lab3;

import java.util.ArrayList;
import java.util.List;

public class Perigoso extends Animal {
    private char classe;
    private List<Animal> alimentos = new ArrayList<Animal>();
    public char getClasse() {
        return classe;
    }
    public void setClasse(char classe) {
        this.classe = classe;
    }
    public List<Animal> getAlimentos() {
        return alimentos;
    }
    public void setAlimentos(List<Animal> alimentos) {
        this.alimentos = alimentos;
    }
   


}
