package br.edu.unifei.ecot12a.lab3;

public class Materializacao {
    private String elemento;

    public String getElemento() {
        return elemento;
    }

    public void setElemento(String elemento) {
        this.elemento = elemento;
    }

    

}
