package br.edu.unifei.ecot12.fringe;

public class Alternativo implements Universo{

    @Override
    public int vph(int idade) {
        return idade*666;
    }
}
