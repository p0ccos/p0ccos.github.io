package br.edu.unifei.ecot12.lab09.salgado;

public class Esfirra extends Salgado {
    private boolean aberta;
    public boolean isAberta() {
        return aberta;
    }

   public void setAberta(boolean aberta) {
        this.aberta = aberta;
    }
   protected Esfirra(){}

}
