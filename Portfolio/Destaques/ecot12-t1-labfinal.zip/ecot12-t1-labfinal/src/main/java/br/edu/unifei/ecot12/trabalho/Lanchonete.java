package br.edu.unifei.ecot12.trabalho;


public class Lanchonete extends Comercio {

    private String lanche;
    private String bebida;
    
    public String getLanche() {
        return lanche;
    }
    public void setLanche(String lanche, Humano cliente) {
        this.lanche = lanche;
    }
    public String getBebida() {
        return bebida;
    }
    public void setBebida(String bebida) {
        this.bebida = bebida;
    }

    
}
