package br.edu.unifei.ecot12.spider;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}