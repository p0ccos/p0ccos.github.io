package br.edu.unifei.ecot12.trabalho;

public class Cobra extends Animal {

    private double tamanho;

    public double getTamanho() {
        return tamanho;
    }

    public void setTamanho(double tamanho) {
        this.tamanho = tamanho;
    }

    public Cobra(String nome){
        super(nome,10);
    }
}
