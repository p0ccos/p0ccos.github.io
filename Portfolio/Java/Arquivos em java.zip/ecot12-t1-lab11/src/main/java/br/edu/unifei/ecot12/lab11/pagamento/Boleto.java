package br.edu.unifei.ecot12.lab11.pagamento;

import java.sql.Date;

public class Boleto {
    private Date vencimento;
    private int agencia;
    private int conta;
    private float valor;

    public float pagarEmAtraso(){
        return valor*1.035f;
    }

    public float pagarSemAtraso(){
        return valor;
    }

    public Date getVencimento() {
        return vencimento;
    }

    public void setVencimento(Date vencimento) {
        this.vencimento = vencimento;
    }

    public int getAgencia() {
        return agencia;
    }

    public void setAgencia(int agencia) {
        this.agencia = agencia;
    }

    public int getConta() {
        return conta;
    }

    public void setConta(int conta) {
        this.conta = conta;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }
    
}
