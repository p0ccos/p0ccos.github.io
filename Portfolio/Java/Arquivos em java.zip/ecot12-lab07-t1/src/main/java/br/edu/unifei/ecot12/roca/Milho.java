package br.edu.unifei.ecot12.roca;

public class Milho implements Producao {


    private int caixas;

    public int getCaixas() {
        return caixas;
    }

    public void setCaixas(int caixas) {
        this.caixas = caixas;
    }

    @Override
    public void atualizar(int dif) {
        caixas*=((100.0+dif)/100.0);
    }

}
