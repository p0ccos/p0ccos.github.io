package br.edu.unifei.ecot12.advinho;

public class Main {
    public static void main(String[] args) {
        Oraculo o1 = Oraculo.getInstancia();
        System.out.println(o1);
    }

}
