package br.edu.unifei.ecot12a.lab3;

import java.util.ArrayList;
import java.util.List;

public class Bruxo extends Humano {
    private String tipoSangue;
    private boolean fantasma;
    private Perigoso parasita;
    private List<Feitico> conjuram = new ArrayList<Feitico>();
    public String getTipoSangue() {
        return tipoSangue;
    }
    public void setTipoSangue(String tipoSangue) {
        this.tipoSangue = tipoSangue;
    }
    public boolean isFantasma() {
        return fantasma;
    }
    public void setFantasma(boolean fantasma) {
        this.fantasma = fantasma;
    }
    public Perigoso getParasita() {
        return parasita;
    }
    public void setParasita(Perigoso parasita) {
        this.parasita = parasita;
    }
    public List<Feitico> getConjuram() {
        return conjuram;
    }
    public void setConjura(List<Feitico> conjuram) {
        this.conjuram = conjuram;
    }



}
