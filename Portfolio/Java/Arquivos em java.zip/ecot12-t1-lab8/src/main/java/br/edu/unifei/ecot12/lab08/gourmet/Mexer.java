package br.edu.unifei.ecot12.lab08.gourmet;

public class Mexer extends Passo {

    private int minutos;
    public Mexer(float quantidade, String unidade, String ingrediente, int minutos) {
        super(quantidade, unidade, ingrediente);
        this.minutos = minutos;
        
    }
    public int getMinutos() {
        return minutos;
    }
    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }
    

}
