package br.edu.unifei.ecot12.lab11.hulk;

public class Civilizado implements Estado{

    private float raciocinio;
    private float observacao;

    @Override
    public void transformacao(Pessoa p) {
        if(p.getRaiva()>=0.8){
            p.setEstado(new Selvagem());
        }
    }

    public float getRaciocinio() {
        return raciocinio;
    }

    public void setRaciocinio(float raciocinio) {
        this.raciocinio = raciocinio;
    }

    public float getObservacao() {
        return observacao;
    }

    public void setObservacao(float observacao) {
        this.observacao = observacao;
    }
    

}
