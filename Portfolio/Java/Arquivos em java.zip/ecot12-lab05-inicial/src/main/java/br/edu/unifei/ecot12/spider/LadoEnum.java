package br.edu.unifei.ecot12.spider;

public enum LadoEnum {
	BEM, MAL;
}
