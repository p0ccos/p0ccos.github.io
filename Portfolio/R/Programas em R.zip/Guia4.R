#Guia 5 do Laboratório de ECO141A
#Poliana Cruz Costa 2023001648

# Instalacao e carregamento dos pacotes
lista.de.pacotes <- c("data.table","rstudioapi","dplyr")
novos.pacotes <- lista.de.pacotes[!(lista.de.pacotes %in% installed.packages()[,"Package"])]
if(length(novos.pacotes)) install.packages(novos.pacotes)
lapply(lista.de.pacotes, require, character.only = TRUE)

# Definicao da trilha de dados
# Definindo a trilha SE o script estiver dentro da pasta
my.path <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(my.path)

# Ler o arquivo de dados
dados <- as.data.frame(fread("dados_est_desc.csv"))
head(dados)


glimpse(dados)
head(dados)
# Média

#Tenta calcular a média do dataframe inteiro
#mean(dados, na.rm=T)
#Média da coluna 5, com remoção de valores inválidos (NA). Parâmetro - [na.rm=T]
mean(dados[,5], na.rm=T)
#Média da coluna denominada temperatura
mean(dados$Temperatura, na.rm=T)
#Tenta calcular a média das colunas
#colMeans(dados, na.rm=T)
#Tenta calcular a média das linhas
#rowMeans(dados, na.rm=T)

#Função aggregate data frame retorna um data frame após a execução das funções
#media<-aggregate.data.frame(x = dados, by = list(dados$Estado), FUN=mean)
#media
media<-aggregate.data.frame(x = dados, by = list(dados$Estado,dados$Cidade), FUN=mean)
media

#Calcular, seguindo os exemplos acima
# 1) Mediana - função median()
mediana<-aggregate.data.frame(x = dados, by = list(dados$Estados,dados$Cidade), FUN = median)
mediana
# 2) Máximo - função max()
maximo<-aggregate.data.frame(x = dados, by = list(dados$Estado,dados$Cidade), FUN = max)
maximo
# 3) Mínimo - função min()
minimo<-aggregate.data.frame(x = dados, by = list(dados$Estado,dados$Cidade), FUN = min)
minimo
# 4) Amplitude - equação: função max() - min()
ampli<-function(x){
  if(is.numeric(x)){
    maximo<-max(x)
    minimo<-min(x)
    amplitude<-maximo-minimo
    return(amplitude)
  }
  return (NA)
}
amplitude<-aggregate.data.frame(x = dados, by = list(dados$Estado,dados$Cidade), FUN = ampli)
amplitude
# 5) Variância - função var()
variancia<-aggregate.data.frame(x = dados, by = list(dados$Estado,dados$Cidade), FUN = var)
variancia
# 6) Desvio Padrão - função sd()
desvio<-aggregate.data.frame(x = dados, by = list(dados$Estado,dados$Cidade), FUN = sd)
desvio
# 7) Erro padrão da média - equação: sd()/sqrt(N) 
errop<-function(x){
  if(is.numeric(x)){
    desviopad<-sd(x)
    tam<-length(x)
    erropadrao<-desviopad/sqrt(tam)
    return(erropadrao)
  }
  return(NA)
}
errop<-aggregate.data.frame(x = dados, by = list(dados$Estado, dados$Cidade), FUN = errop)
errop

# 8) Coeficiente de variação - equação: (sd()/mean()) * 100
cv<-function(x){
  if(is.numeric(x)){
    desvio<-sd(x)
    media<-mean(x)
    var<-(desvio/media)*100
    return (var)
  }
  return(NA)
}
variancia<-aggregate.data.frame(x = dados, by = list(dados$Estado), FUN=cv)
variancia

