package br.edu.unifei.ecot12a.lab3;

public class Humano extends Mortal {
    private String profissao;

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }

    

}
