package br.edu.unifei.ecot12.trabalho;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Festa {

    private String nome;
    private Lugar local;
    private Calendar data;
    private String horario;
    private List<Ser> participantes = new ArrayList<Ser>();
    
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public Lugar getLocal() {
        return local;
    }
    public void setLocal(Lugar local) {
        this.local = local;
    }
    public Calendar getData() {
        return data;
    }
    public void setData(Calendar data) {
        this.data = data;
    }
    public String getHorario() {
        return horario;
    }
    public void setHorario(String hora) {
        this.horario = hora;
    }
    public List<Ser> getParticipantes() {
        return participantes;
    }
    public void setParticipantes(List<Ser> participantes) {
        this.participantes = participantes;
    }

    public Festa(String nome){
        this.nome = nome;
    }
    
    

}
