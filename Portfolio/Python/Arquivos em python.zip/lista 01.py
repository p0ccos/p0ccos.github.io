#Ex_03

#entrada de uma frase
a = input("Digite uma palavra ou frase: ")
#tamanho da string para realizar operação
b = len(a)
#remove todos os espaços
c = a.replace(" ","")
#sem espaços em branco
c = c.strip()
c = c.lower()

print(a)
print(b)
print(c)
print(len(c))
d = len(c)

def palindromo(c):
    for i in range (d//2):
        if c[i] != c[d - i - 1]:
            return False
    return True

if palindromo(c):
    print("Eh um palindromo.")
else:
    print("Não eh um palindromo.")

###########################################################
#Ex_04
