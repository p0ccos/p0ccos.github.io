package br.edu.unifei.ecot12.trabalho;

public class Vagalume extends Animal {

    private int quantidadeDentes;
    private boolean luzAcesa;
    
    public int getQuantidadeDentes() {
        return quantidadeDentes;
    }
    public void setQuantidadeDentes(int quantidadeDentes) {
        this.quantidadeDentes = quantidadeDentes;
    }
    public boolean isLuzAcesa() {
        return luzAcesa;
    }
    public void setLuzAcesa(boolean luzAcesa) {
        this.luzAcesa = luzAcesa;
    }

    public Vagalume(String nome){
        super(nome,10);
        
    }

    
}
