package br.edu.unifei.ecot12.eletrica;

public abstract class Elementos {
    private String rotulo;

    public String getRotulo() {
        return rotulo;
    }

    public void setRotulo(String rotulo) {
        this.rotulo = rotulo;
    }

    public abstract int totalElementos();


}
