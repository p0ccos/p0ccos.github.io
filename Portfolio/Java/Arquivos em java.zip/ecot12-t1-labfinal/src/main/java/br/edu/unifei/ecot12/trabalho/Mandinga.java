package br.edu.unifei.ecot12.trabalho;

public class Mandinga extends Magia{
    private int nivelSangue;

    public int getNivelSangue() {
        return nivelSangue;
    }
    public void setNivelSangue(int nivelSangue) {
        this.nivelSangue = nivelSangue;
    }   

    //contrutor
    public Mandinga(String poder){
        super(poder);

    }
    @Override
    public void atualizar(String mensagem) {
        System.out.println("recebeu "+mensagem);
    }

    

}
