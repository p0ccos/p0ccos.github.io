package br.edu.unifei.ecot12.trabalho;

public class Invocacao {
    private Humano invocador;
    private Sombra sombra;
    public Humano getInvocador() {
        return invocador;
    }
    public void setInvocador(Humano invocador) {
        this.invocador = invocador;
    }
    public Sombra getSombra() {
        return sombra;
    }
    public void setSombra(Sombra sombra) {
        this.sombra = sombra;
    }

    public Sombra invocarSombras(Humano alguem){
        if("feiticeiro".equals(alguem.getOcupacao())){//"feiticeiro".equals(alguem.getOcupacao())
            Sombra sombras = new Sombra();
            
            System.out.println(alguem.getNome()+" conseguiu invocar sombras!");
            return sombras;
        }
        return null;
    }
}
