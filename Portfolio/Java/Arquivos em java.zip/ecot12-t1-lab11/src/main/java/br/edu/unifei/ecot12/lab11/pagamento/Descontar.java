package br.edu.unifei.ecot12.lab11.pagamento;

public class Descontar implements Comando {

    private Cheque cheque;
    
    public Descontar(Cheque cheque) {
        this.cheque = cheque;
    }

    @Override
    public void executar() {
        cheque.descontar();
    }

    public Cheque getCheque() {
        return cheque;
    }

    public void setCheque(Cheque cheque) {
        this.cheque = cheque;
    }

    
}
