package br.edu.unifei.ecot12.trabalho;

public class Caldeirao extends Magia{
    private boolean temperado;
    private String tempero;

    public boolean isTemperado() {
        return temperado;
    }
    public void setTemperado(boolean temperado) {
        this.temperado = temperado;
    }
   

    public String getTempero() {
        return tempero;
    }
    public void setTempero(String tempero) {
        this.tempero = tempero;
    }
    @Override
    public void atualizar(String mensagem) {
        System.out.print(mensagem);
    }
    public Caldeirao(){
        super("visão");
    }

    public void encanto(String tempero){
        if("tabasco".equals(tempero)){
            System.out.print("está temperada e mostrou a visão. ");
            
        }else{
            System.out.print("não está temperada o suficiente, portanto não mostrará a visão. ");
        }
        
    }
}
