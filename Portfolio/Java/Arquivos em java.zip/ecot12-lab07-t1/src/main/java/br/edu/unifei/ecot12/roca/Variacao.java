package br.edu.unifei.ecot12.roca;

import java.util.ArrayList;
import java.util.List;

public abstract class Variacao {

    private List<Producao> produtos = new ArrayList<Producao>();

    public List<Producao> getProdutos() {
        return produtos;
    }

    public void setProdutos(List<Producao> produtos) {
        this.produtos = produtos;
    }
    
    protected void notificar(int dif){
        for(Producao p : produtos)
            p.atualizar(dif);
    }
}
