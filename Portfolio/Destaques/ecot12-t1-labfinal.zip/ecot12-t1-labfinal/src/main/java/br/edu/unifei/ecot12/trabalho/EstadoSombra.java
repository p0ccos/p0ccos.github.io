package br.edu.unifei.ecot12.trabalho;

public class EstadoSombra implements EstadoSer{

    @Override
    public Ser transformaSer(Ser ser) {

        System.out.println(ser.getNome() + " se tornou Humano!");
        ser.setEstado(new EstadoHumano());
        Humano humano = new Humano(ser.getNome(), ser.getIdade(), null);
        return humano;
    }

    @Override
    public String toString() {
        return "sombra";
    }
}
