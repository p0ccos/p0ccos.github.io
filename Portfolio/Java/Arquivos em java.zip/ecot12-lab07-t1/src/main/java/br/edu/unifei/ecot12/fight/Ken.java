package br.edu.unifei.ecot12.fight;

public class Ken extends Personagem{
    private int bloqueio=100;
    private int dano=100;
    private int impulso=100;

    public void shoryuken(){
        chamarBater();
    }

    public int getBloqueio() {
        return bloqueio;
    }

    public void setBloqueio(int bloqueio) {
        this.bloqueio = bloqueio;
    }

    public int getDano() {
        return dano;
    }

    public void setDano(int dano) {
        this.dano = dano;
    }

    public int getImpulso() {
        return impulso;
    }

    public void setImpulso(int impulso) {
        this.impulso = impulso;
    }
}
