package br.edu.unifei.ecot12.trabalho;

public class Instrumento {

    private String nome;
    private String categoria;
    private String material;
    
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getCategoria() {
        return categoria;
    }
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    public String getMaterial() {
        return material;
    }
    public void setMaterial(String material) {
        this.material = material;
    }

    public Instrumento(String nome){
        this.nome = nome;
    }
    

}
