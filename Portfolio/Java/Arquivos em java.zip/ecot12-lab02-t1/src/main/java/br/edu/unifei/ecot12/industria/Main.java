package br.edu.unifei.ecot12.industria;

public class Main {
    public static void main(String[] args) {
        Departamento v = new Departamento();
        v.setNome("vendas");
        Funcionario z = new Funcionario();
        z.setNome("Zé");
        z.setDepartamento(v);
        v.getFuncionarios().add(z);//biddirecional

        Funcionario m = new Funcionario();
        m.setNome("Maria");
        m.setDepartamento(v);
        v.getFuncionarios().add(m);

        Projeto p = new Projeto();
        
        p.setNumero(100);
        p.setDepartamento(v);
        m.getProjetos().add(p);
        p.setGerente(m);
        p.getFuncionarios().add(z);
        z.getProjetos().add(p);

        System.out.println("Funcionarios de vendas:");
        for(Funcionario f:v.getFuncionarios()){
            System.out.println(f.getNome());
        }

    }

}
