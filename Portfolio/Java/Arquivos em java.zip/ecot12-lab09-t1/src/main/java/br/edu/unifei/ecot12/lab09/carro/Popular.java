package br.edu.unifei.ecot12.lab09.carro;

public class Popular implements Segmento {

    @Override
    public void construirMotor(Carro c) {
        
        c.getMotor().setCilindros(3);
        c.getMotor().setCombustivel("Flex");
        c.getMotor().setPotencia(1.0f);  
    }

}
