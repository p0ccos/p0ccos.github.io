package br.edu.unifei.ecot12.lab09.carro;

public class Main {
    public static void main(String[] args) {
        Montadora m = new Montadora();
        m.setSegmento(new Luxo());
        Carro c1 = m.construir();

        System.out.println(c1.getMotor().getCombustivel());
        m.setSegmento(new Popular());
        Carro c2 = m.construir();
        System.out.println(c2.getMotor().getCombustivel());

    }
}