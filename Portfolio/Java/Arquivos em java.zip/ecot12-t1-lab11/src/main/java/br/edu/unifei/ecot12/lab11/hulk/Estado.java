package br.edu.unifei.ecot12.lab11.hulk;

public interface Estado {

    public void transformacao(Pessoa p);

}
