package br.edu.unifei.ecot12.fringe;

public interface Universo {
    public int vph(int idade);
}
