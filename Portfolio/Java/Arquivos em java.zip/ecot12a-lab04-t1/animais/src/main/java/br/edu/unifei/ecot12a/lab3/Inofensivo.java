package br.edu.unifei.ecot12a.lab3;

import java.util.ArrayList;
import java.util.List;

public class Inofensivo extends Animal {
    private boolean camuflagem;
    private List<Planta> alimentos = new ArrayList<Planta>();
    public boolean isCamuflagem() {
        return camuflagem;
    }
    public void setCamuflagem(boolean camuflagem) {
        this.camuflagem = camuflagem;
    }
    public List<Planta> getAlimentos() {
        return alimentos;
    }
    public void setAlimentos(List<Planta> alimentos) {
        this.alimentos = alimentos;
    }

    
}
