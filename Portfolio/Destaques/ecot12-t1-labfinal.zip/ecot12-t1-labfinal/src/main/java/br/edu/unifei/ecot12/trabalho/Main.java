package br.edu.unifei.ecot12.trabalho;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        System.out.println("A Princesa e o Sapo");
        System.out.println("Filme da Disney - 2009\n");
        System.out.println("===================================================================================================");

        // Criar figurantes
        List<Humano> figurantes = criarFigurantes();

        // Lista para armazenar passageiros e funcionarios
        List<Humano> passageiros1 = new ArrayList<>();
        List<Humano> passageiros2 = new ArrayList<>();
        List<Humano> passageiros3 = new ArrayList<>();
        List<Humano> funcionarios1 = new ArrayList<>();
        List<Humano> clientes1 = new ArrayList<>();

        // Selecionar 5 passageiros aleatórios
        Collections.shuffle(figurantes); // Embaralhar lista de figurantes
        passageiros1.addAll(figurantes.subList(0, 10)); // Adicionar os primeiros da lista embaralhada
        Collections.shuffle(figurantes);
        passageiros2.addAll(figurantes.subList(0, 7));
        Collections.shuffle(figurantes);
        passageiros3.addAll(figurantes.subList(0, 18));
        funcionarios1.addAll(figurantes.subList(2, 4));
        clientes1.addAll(figurantes.subList(5, 10));
    
        //Criar cidade do filme
        Lugar novaOrleans = new Lugar("Nova Orleans");

        // Criar humano com nome, idade e ocupação
        Humano eliLaBouff = new Humano("Eli LaBouff", 42, "muito rico");
        
        // Criar lugar com nome
        Lugar casaLaBouff = new Lugar("casa dos LaBouff");
        Lugar casaTiana = new Lugar("casa");

        // Criar veículo com numero, nome, tipo e qtd de passageiros
        Veiculo bonde1 = new Veiculo(1,"bonde",TipoEnum.TERRESTRE,50);

        // Criar viagem com duração, origem, destino e veiculo
        Viagem viagem1 = new Viagem(15,casaLaBouff,casaTiana,bonde1);

        Humano eldora = new Humano("Eldora",35,"costureira");
        eldora.setPatrao(eliLaBouff);
        
        Lugar servicoJames = new Lugar("serviço");
        Veiculo bonde2 = new Veiculo(2,"bonde",TipoEnum.TERRESTRE,20);
        Viagem viagem2 = new Viagem(40, servicoJames, casaTiana, bonde2);

        Humano james = new Humano("James",38,"dois/três turnos");
        james.setSonho("abrir um restaurante");

        // Adicionar passageiros a viagem
        viagem2.getPassageiros().add(james);
        for (Humano passageiro : passageiros3) {
            viagem2.getPassageiros().add(passageiro);
        }
        
        Humano tiana = new Humano("Tiana",5,"brincar e ajudar os pais");
        tiana.setSonho("abrir um restaurante");
        tiana.setPai(james);
        tiana.setMae(eldora);

        viagem1.getPassageiros().add(tiana);
        viagem1.getPassageiros().add(eldora);

        for (Humano passageiro : passageiros3) {
            viagem1.getPassageiros().add(passageiro);
        }
        
        Humano charlotte = new Humano("Charlotte",5,"brincar");
        charlotte.setSonho("casar-se com um príncipe e virar uma princesa");
        charlotte.setPai(eliLaBouff);

        Cachorro estela = new Cachorro("Estela");
        charlotte.setPossui(estela);
        estela.setDono(charlotte);

        // Inicio da história
        System.out.println("A "+tiana.getNome()+" tem "+tiana.getIdade()+ " anos e gosta de "+tiana.getOcupacao()+".");
        System.out.println("Seu pai "+tiana.getPai().getNome()+" tem "+james.getIdade()+ " anos e trabalha "+james.getOcupacao()+
                            " e tem o sonho de "+james.getSonho()+".");
        System.out.println("Sua mãe "+tiana.getMae().getNome()+" tem "+eldora.getIdade()+ " anos e trabalha como "
                            +eldora.getOcupacao()+" para o "+eldora.getPatrao().getNome()+",");
        System.out.println("pai de "+charlotte.getNome()+" uma menina de "+charlotte.getIdade()+" anos que sonha em "+charlotte.getSonho());
        System.out.println(eliLaBouff.getNome()+" mais conhecido como Sr. LaBouff, deu uma cachorrinha que se chama "+estela.getNome()+" para sua filha.\n");

        //Alguns anos depois
        james.setVivo(false);
        System.out.println("Quinze anos se passaram, e neste tempo o pai de "+tiana.getNome()+ 
                            " morre sem realizar seu sonho. Então ela fica \nainda mais determinada a "+tiana.getSonho()+".");
        
        Restaurante restaurante1 = new Restaurante();
        restaurante1.getFuncionario().add(tiana);
        restaurante1.setTurno("a noite");

        Lanchonete lanchonete1 = new Lanchonete();
        lanchonete1.getFuncionario().add(tiana);
        lanchonete1.setTurno("o dia");

        //ocupacao de Tiana muda
        tiana.setOcupacao("garçonete");
        tiana.getEmprego().add(lanchonete1);
        tiana.getEmprego().add(restaurante1);

        Lugar lanchonete = new Lugar("lanchonete");
        Veiculo bonde3 = new Veiculo(3,"bonde",TipoEnum.TERRESTRE,20);

        Viagem viagem3 = new Viagem(15, casaTiana, lanchonete, bonde3);

        viagem3.getPassageiros().add(tiana);
        for (Humano passageiro : passageiros3) {
            viagem3.getPassageiros().add(passageiro);
        }

        System.out.print("Pela manhã ela sai de "+viagem3.getOrigem().getNome()+", pega um "+viagem3.getTransporte().getNome()+
                            " até a "+viagem3.getDestino().getNome()+" e trabalha como "+tiana.getOcupacao()+" durante "
                            +lanchonete1.getTurno()+" \ne num restaurante durante "+restaurante1.getTurno()+".\n");

        lanchonete1.getClientes().add(eliLaBouff);
        lanchonete1.getClientes().add(charlotte);
        lanchonete1.getClientes().addAll(clientes1);
        lanchonete1.setLanche("tostadas",eliLaBouff);
        Humano buford = new Humano("Buford", 40, "cozinheiro");
        tiana.setPatrao(buford);

        Lugar maldonia = new Lugar("Maldonia");
        Humano naveen = new Humano("Naveen", 22, "príncipe");
        naveen.setOrigem(maldonia);
        Festa carnaval = new Festa("carnaval");

        System.out.println("O "+eliLaBouff.getNome()+" pediu "+lanchonete1.getLanche()+", "+charlotte.getNome()+" encomendou "
                            +lanchonete1.getLanche()+" para "+tiana.getNome()+" pois seu pai convidou o \n"
                            +naveen.getOcupacao()+" "+naveen.getNome()+" da "+naveen.getOrigem().getNome()
                            +" para ficar em sua casa até o "+carnaval.getNome()+". O dinheiro que "+charlotte.getNome()+
                            " pagou \n"+tiana.getNome()+" foi o suficiente para completar a quantia para comprar seu próprio restaurante.");

        
        Imobiliaria fennersBrothers = new Imobiliaria();
        fennersBrothers.setNome("Irmãos Fenner");
        fennersBrothers.setContrato("Restaurante beira-mar");
        fennersBrothers.setCidade(novaOrleans);

        System.out.println(tiana.getNome()+" mais do que depressa vai até a imobiliária "+fennersBrothers.getNome()+
                            " e deseja assinar o contrato de compra \nde imóvel, onde será seu restaurante, mas o contrato só ficaria pronto" 
                             +"à noite e os Irmãos Fenner \ncombinaram de levar os papéis no baile de máscaras na casa dos Labouff\n");
        
        Humano lowrence = new Humano("Lawrence", 62, "mordomo");
        lowrence.setOrigem(maldonia);
        lowrence.setPatrao(naveen);
        
        Veiculo aviao = new Veiculo(54, "avião", TipoEnum.AEREO, 70);
        Viagem viagem4 = new Viagem(120, maldonia, novaOrleans, aviao);
        viagem4.getPassageiros().add(lowrence);
        viagem4.getPassageiros().add(naveen);
        viagem4.getPassageiros().addAll(figurantes);viagem4.getPassageiros().addAll(figurantes);viagem4.getPassageiros().addAll(figurantes);

        Instrumento ukulele = new Instrumento("ukulele");
        naveen.setToca(ukulele);

        System.out.println("O "+naveen.getOcupacao()+" "+naveen.getNome()+" viajou de "+viagem4.getOrigem().getNome()+" para "+viagem4.getDestino().getNome()
                            +" de "+viagem4.getTransporte().getNome()+" junto de "+lowrence.getNome()+" seu "+lowrence.getOcupacao()+".");
        System.out.println("O "+naveen.getOcupacao()+" gosta muito de música e quando ele chega, logo se junta a uma banda que passava por \nperto. Ele pega seu "
                            +naveen.getToca().getNome()+" e começa a tocar.");
        
        String mensagem = "sangue.";
        Transformacao transf = new Transformacao();
        Humano facilier = new Humano("Dr. Facilier", 57, "feiticeiro");

        Mandinga mandinga = new Mandinga("transformação");
        mandinga.setFeiticeiro(facilier);
        mandinga.setNivelSangue(100);
        
        System.out.print("O "+facilier.getNome()+" se aproxima com muito carisma, lê o futuro dos dois e ao concordarem em realizar \no futuro, "
                            +naveen.getNome()+" é amarrado por duas cobras e é mordido pela mandinga que ");
        
        mandinga.atualizar(mensagem);
        transf.setStatus(mensagem, naveen, true,lowrence);
        mandinga.setPossui(lowrence);
        
        System.out.println(transf.getStatus());
        
        //Baile na casa dos LaBouff
        Festa baile = new Festa("baile");
        baile.setLocal(casaLaBouff);
        System.out.println("\nNa "+baile.getLocal().getNome()+" tem um "+baile.getNome()+" de máscaras acontecendo. "
                            +tiana.getNome()+" está servindo "+lanchonete1.getLanche()+". O falso \n"+naveen.getOcupacao()+
                            " "+naveen.getNome()+" aparece e dança com "+charlotte.getNome()+" que se apaixona por ele.");


        System.out.println("Os irmãos Fenners aparecem na festa e dizem a "+tiana.getNome()+" que apareceu uma outra oferta"+
                            " pelo imóvel e \nela precisa cobrir a oferta até o fim do "+carnaval.getNome()+" ou ela perde o imóvel.");
        System.out.println("Na tentativa de tentar conversar com os irmãos Fenners, "+tiana.getNome()+" cai na mesa das "
                            +lanchonete1.getLanche()+" e fica \ntoda suja. Sua amiga "+charlotte.getNome()+
                            " lhe empresta um vestido e uma coroa de princesa e volta a \ndançar.\n");
        System.out.println(tiana.getNome()+" ainda sem acreditar que pode perder o imóvel, fica muito triste e faz um pedido a estrela \n"
                            +"e no mesmo instante aparece um sapo dizendo ser o verdadeiro "+naveen.getOcupacao()+" "+naveen.getNome()
                            +". Ele a convence de \no beijar para que ele se transforme novamente em humano porque a história diz que se"+
                            " uma princesa \nbeija o príncipe sapo, ele volta a ser humano.");    
        System.out.print("Ela o beijou e puff.....");
        tiana.realizarTransformacao();

        System.out.println("\n"+tiana.getNome()+" e "+naveen.getNome()+" acabam parando em um pantano cheio de crocodilos que querem devorá-los. "+
                            tiana.getNome()+" logo \nconsegue achar um esconderijo e "+naveen.getNome()+" promete dar o restaurante para ela se o "+
                            "ajudasse a se \nesconder também. Ela o ajuda e a noite passa.");
        Crocodilo louis = new Crocodilo("Louis");
        Instrumento trompete = new Instrumento("trompete");
        louis.setToca(trompete);
        louis.setSonho("tocar de improviso com os famosos");
        System.out.println("Pela manhã, "+tiana.getNome()+" decide procurar alguém que acaba com magia e conhecem o crocodilo "+louis.getNome()+
                            " que toca \n"+louis.getToca().getNome()+" e logo se dá bem com "+naveen.getNome()+" que pega um galho e toca como se fosse um ukulele.");

        Humano mamaOdie = new Humano("Mama Odie", 197, "feiticeira");
        System.out.println(louis.getNome()+" sonha em "+louis.getSonho()+" e diz conhecer "+mamaOdie.getNome()+" que é uma "+mamaOdie.getOcupacao()+
                            " do \nrio e os três partem em busca de se tornarem humanos.\n");
        Vagalume ray = new Vagalume("Raymond");
        ray.setLuzAcesa(false);
        ray.setSonho("formar um casal com Evangeline");
        Lugar arvore = new Lugar("casa na árvore");

        System.out.println("Conhecem "+ray.getNome()+", um vagalume que apresenta sua família e os guiam para o caminho da "+arvore.getNome()
                            +" \nde "+mamaOdie.getNome()+".");

        System.out.print(charlotte.getNome()+" e o falso "+naveen.getNome()+" estão conversando e ele a pede em casamento."); 
        System.out.println("O nível de sangue da manginga \nacaba. Ela fica tão contente que nem percebe que ");
        mandinga.setNivelSangue(0);
        transf.setStatus(mensagem, naveen, false,lowrence);
        System.out.println(transf.getStatus());

        Invocacao invocarSombra = new Invocacao();
        Sombra sombra = invocarSombra.invocarSombras(facilier);
        sombra.setInvoca(facilier);
        
        System.out.println("Ele ordena que as sombras capturem "+naveen.getNome()+" que está como "+naveen.getEstado()+".\n");


        Humano joel = new Humano("Joel", 25, "caçador");
        Humano doisDedo = new Humano("Dois Dedo", 59, "caçador");
        Humano reggie = new Humano("Reggie", 52, "caçador");

        System.out.println("Enquanto isso na floresta, os caçadores "+reggie.getNome()+", "+doisDedo.getNome()+
                            " e "+joel.getNome()+" estão caçando dois sapos que são \n"+naveen.getNome()+" e "
                            +tiana.getNome()+".");

        Cacar cacaSapo = new Cacar();
        cacaSapo.getCacadores().add(reggie);
        cacaSapo.getCacadores().add(joel);
        cacaSapo.getCacadores().add(doisDedo);
        cacaSapo.getPresa().add(tiana);
        cacaSapo.getPresa().add(naveen);
        cacaSapo.captura(naveen,reggie);
        cacaSapo.captura(tiana,joel);

        System.out.print("Ambos tentam fugir. ");
        cacaSapo.fuga(naveen);
        System.out.print("Ele a ajuda. ");
        cacaSapo.fuga(tiana);

        Cacar cacaNaveen = new Cacar();
        cacaNaveen.captura(naveen, sombra);
        cacaNaveen.desfaz(naveen, sombra, mamaOdie);

        Cobra juju = new Cobra("juju");
        juju.setDono(mamaOdie);
        mamaOdie.setPossui(juju);
        System.out.println(mamaOdie.getNome()+" é dona de "+juju.getNome()+", uma cobra muito atenciosa. ");


        System.out.println("No caldeirão, há uma sopa que ");
        Caldeirao caldeirao = new Caldeirao();
        caldeirao.encanto("sal");
        System.out.print(juju.getNome()+" colocou o ");
        caldeirao.atualizar("tempero");
        System.out.println(" então agora ");
        caldeirao.encanto("tabasco");

        Veiculo navio = new Veiculo(5466,"navio" , TipoEnum.AEREO, 50);
        Lugar porto = new Lugar("Porto de Nova Orleans");
        Viagem viagem5 = new Viagem(30, arvore, porto, navio);
        viagem5.getPassageiros().add(naveen);
        viagem5.getPassageiros().add(tiana);
        viagem5.getPassageiros().add(ray);
        viagem5.getPassageiros().add(louis);
        viagem5.getPassageiros().addAll(passageiros1);
        viagem5.getPassageiros().addAll(passageiros2);
        viagem5.getPassageiros().addAll(passageiros3);

        System.out.println("A visão mostra que Charlotte será uma princesa até o fim do \ncarnaval e ela beijando Naveen, ele e "
                            +tiana.getNome()+" voltam a serem humanos. "+"Então embarcam em um navio que \nsai da "+arvore.getNome()+" para o "+porto.getNome()+". \n");
        Cacar sapoSombra = new Cacar();
        sapoSombra.getPresa().add(naveen);
        sapoSombra.getCacadores().add(sombra);
        sapoSombra.captura(naveen, sombra);

        System.out.print("A mandinga ");
        mandinga.setNivelSangue(100);
        mandinga.atualizar(mensagem);
        transf.setStatus(mensagem, naveen, true, lowrence);
        System.out.println(transf.getStatus());

        System.out.print(lowrence.getNome()+" vai pro altar com "+charlotte.getNome()+" enquanto "
                            +ray.getNome()+" ajuda "+naveen.getNome()+" escapar. ");
        sapoSombra.fuga(naveen);
        System.out.print("Ele tira a mandinga de "+lowrence.getNome()+" e ");
        transf.setStatus("tirou mandinga",  naveen, true, lowrence);
        System.out.println(transf.getStatus());


        tiana.destruir(mandinga);
        sombra.captura(facilier);
        System.out.println(tiana.getNome()+" quebrou a mandinga e "+sombra.getNome()+" capturou "+facilier.getNome()+". A polícia prende "+lowrence.getNome()+".");
        System.out.println(naveen.getNome()+" conta a história para "+charlotte.getNome()+", ela o beija mas nada acontece porque já havia acabado o carnaval.");
        
        //casamento
        Festa casamento = new Festa("casamento");
        Borboleta b = new Borboleta("verde");

        casamento.getParticipantes().add(tiana);
        casamento.getParticipantes().add(naveen);
        casamento.getParticipantes().add(juju);
        casamento.getParticipantes().add(mamaOdie);
        casamento.getParticipantes().add(b);
        System.out.println(naveen.getNome()+" usa uma borboleta como gravata e ela o parabeniza. "+naveen.getNome()+" e "
                                    +tiana.getNome()+" se casam e no momento que se beijam.... puff!!!");

        tiana.realizarTransformacao();
        naveen.realizarTransformacao();
        System.out.println("Por fim, "+tiana.getNome()+" consegue abrir seu tão sonhado restaurante!");
    }

    // Função para criar 20 figurantes humanos
    public static List<Humano> criarFigurantes() {
        List<Humano> figurantes = new ArrayList<>();
        Random random = new Random();

        // Listas de dados para gerar nomes e ocupações aleatórias
        String[] nomes = {"Lucas", "Ana", "Carlos", "Maria", "João", "Clara", "Gabriel", "Fernanda", "Pedro", "Juliana",
                          "Paulo", "Isabela", "Renato", "Alice", "Miguel", "Beatriz", "Ricardo", "Sofia", "Thiago", "Larissa"};
        String[] ocupacoes = {"Estudante", "Professor", "Engenheiro", "Médico", "Ator", "Cantor", "Artista", "Escritor", "Advogado", "Empresário"};

        // Gerar 20 figurantes
        for (int i = 0; i < 20; i++) {
            String nome = nomes[random.nextInt(nomes.length)]; // Nome aleatório
            int idade = random.nextInt(60) + 18; // Idade entre 18 e 77 anos
            String ocupacao = ocupacoes[random.nextInt(ocupacoes.length)]; // Ocupação aleatória

            Humano figurante = new Humano(nome, idade, ocupacao);
            figurantes.add(figurante);
        }

        return figurantes;
    }
  
}