package br.edu.unifei.ecot12.trabalho;

public class Cachorro extends Animal {

    private boolean muitoPelo;
    private String raca;

    public boolean isMuitoPelo() {
        return muitoPelo;
    }
    public void setMuitoPelo(boolean muitoPelo) {
        this.muitoPelo = muitoPelo;
    }
    public String getRaca() {
        return raca;
    }
    public void setRaca(String raca) {
        this.raca = raca;
    }
    public Cachorro(String nome){
        super(nome, 0);
    }

    
}
