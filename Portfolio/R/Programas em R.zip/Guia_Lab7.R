
#Criando um conjuntos com 10 bolas coloridas

bolas <- rep(c("red", "blue", "white"), times = c(3,5,2))
bolas

#Fazendo um sorteio aleatório do conjunto de bolas
sample(bolas,5)

#Automatizando o processo de sorteio
#Definindo o número de experimentos
B <- 6

#Criando um evento com as réplicas do experimento
eventos <- replicate(B, sample(bolas, 4))
eventos

#Fazendo a contagem dos eventos encontrados nos experimentos
tab <- table(eventos)
tab

#Ao fazer uma amostra de 10 bolas o conjunto original é encontrado
#Nesse caso, as probabilidades individuais de tirar uma cor são nítidas
# P(red) = 0.3, P(blue) = 0.5 e P(white) = 0.2
sample(bolas, 10)

#Façamos uma simulação de Monte Carlo com 10000 experimentos,
#selecionando uma bola por experimento e contando quantas são obtidas:



B <- 10000
eventos <- replicate(B,sample(bolas,1))
tab <- table(eventos)
tab

#Usando prop para conferir as proporções:

prop.table(tab)

#Exemplo 2
#Verificar a probabilidade de obter duas bolas azuis nas duas primeiras escolhas
#Retiradas sem substituição
#P(BB) = 5/10 * 4/9 = 0.222

experimento <- sample(bolas,2)
experimento

#Repetindo o experimento 10 vezes

B <-10
bolasazuis <- replicate(B,{experimento <- sample(bolas,2) 
(experimento[1]=="blue" & experimento[2]=="blue")})

bolasazuis

#Observando a média de vezes que ocorreu o evento BB

mean(bolasazuis)

#Observando a média em um experimento com 10.000 repetições

B <- 10000
bolasazuis <- replicate(B, {experimento <- sample(bolas, 2)
(experimento[1]== "blue" & experimento[2] == "blue")})

mean(bolasazuis)

## Exercícios
## 1º
## Utilizando a simulação de Monte Carlo, demonstre a probabilidade de saírem as
## bolas vermelha, branca e azul ao retirarmos 3 bolas, sem reposição. 
## Sabendo que o evento tem P(RBW) = 3/10 * 2/9 * 5/8 = 0.04167
B<-1000
bolasdiversas <- replicate(B, {experimento <- sample(bolas, 3)
(experimento[1]== "red" & experimento[2] == "white" & experimento[3] == "blue")})
mean(bolasdiversas)


## 2º
## Ao selecionar, sem reposição, 5 bolas queremos saber qual é a probabilidade de que
## ao menos 2 bolas sejam vermelhas.
## Resposta buscada: aproximadamente P =  0.5
## Dica: para esse problemas utilize a função str_count() que retorna 1 toda vez que
## uma determinada string aparece. Exemplo str_count(x, "red")
## Dica 2: utilize a seguir o comando length para contar os 1 retornados. 
## Ex: length(which(n==1))

B<-1000
bolasred <- sample(bolas,5)
bolasred
library(stringr)
str_count(bolasred,"red")
contando <- replicate(B,{bolasred<-sample(bolas,5) 
sum(bolasred == "red")>=2})
mean(contando)
## 3º
## De uma caixa com 20 bolas, sendo 6 brancas, 4 vermelhas, 7 azuis e 3 verdes são selecionadas 6,
## sem substituição. 
## (i) Qual é a probabilidade de que a primeira e a última bola da seleção sejam azuis? 
## Resposta buscada: aproximadamente P = 0.11
## (ii) Qual é a probabilidade de que ao menos três bolas sejam brancas? 
## Resposta buscada: aproximadamente P = 0.22
B <- 10000  

bolas <- rep(c("white", "red", "blue", "green"), times = c(6,4,7,3))
bolas


bolaazul <- sample(bolas,6)
bolaazul

bolazul <- replicate(B, {
  bolaazul <- sample(bolas, 6)
  bolaazul[1] == "blue" & bolaazul[6] == "blue"
})

mean(bolazul)

bolabranca3 <- replicate(B, {
  bolaazul <- sample(bolas, 6)
  sum(bolaazul == "white") >= 3
})

mean(bolabranca3)
