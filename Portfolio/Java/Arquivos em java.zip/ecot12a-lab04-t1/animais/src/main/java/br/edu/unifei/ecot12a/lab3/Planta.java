package br.edu.unifei.ecot12a.lab3;

public abstract class Planta {
    private String especie;
    private String aparencia;
    public String getEspecie() {
        return especie;
    }
    public void setEspecie(String especie) {
        this.especie = especie;
    }
    public String getAparencia() {
        return aparencia;
    }
    public void setAparencia(String aparencia) {
        this.aparencia = aparencia;
    }

    
}
