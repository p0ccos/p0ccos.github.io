package br.edu.unifei.ecot12.trabalho;

public abstract class Ser {

    private String nome;
    private int idade;
    private Instrumento toca;
    private EstadoSer estado;
    private String sonho;
    private boolean livre;
    private Humano dono;
    private boolean vivo;
    
    public boolean isVivo() {
        return vivo;
    }
    public void setVivo(boolean vivo) {
        this.vivo = vivo;
    }
    public boolean isLivre() {
        return livre;
    }
    public void setLivre(boolean livre) {
        this.livre = livre;
    }
        
    public Ser(String nome, int idade, EstadoSer estado, boolean livre) {
        this.nome = nome;
        this.idade = idade;
        this.estado = estado;
        this.livre = livre;
        this.vivo = true;
    }
    public EstadoSer getEstado() {
        return estado;
    }
    public void setEstado(EstadoSer estado) {
        this.estado = estado;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public int getIdade() {
        return idade;
    }
    public void setIdade(int idade) {
        this.idade = idade;
    }
    public Instrumento getToca() {
        return toca;
    }
    public void setToca(Instrumento toca) {
        this.toca = toca;
    }
    public String getSonho() {
        return sonho;
    }
    public void setSonho(String sonho) {
        this.sonho = sonho;
    }
    public void realizarTransformacao() {
        estado.transformaSer(this);
    }
    public Humano getDono() {
        return dono;
    }
    public void setDono(Humano dono) {
        this.dono = dono;
    }


    
}
