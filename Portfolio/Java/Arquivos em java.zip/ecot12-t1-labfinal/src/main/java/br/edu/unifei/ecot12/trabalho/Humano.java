package br.edu.unifei.ecot12.trabalho;

import java.util.ArrayList;
import java.util.List;

public class Humano extends Ser {

    private String ocupacao;
    private Lugar origem;
    private Humano patrao, pai, mae;
    private List<Comercio> emprego = new ArrayList<Comercio>();
    private Ser possui;

    public Ser getPossui() {
        return possui;
    }

    public void setPossui(Ser possui) {
        this.possui = possui;
        possui.setLivre(!isLivre());
    }

    public String getOcupacao() {
        return ocupacao;
    }

    public void setOcupacao(String ocupacao) {
        this.ocupacao = ocupacao;
    }

    public Lugar getOrigem() {
        return origem;
    }

    public void setOrigem(Lugar origem) {
        this.origem = origem;
    }

    public Humano getPatrao() {
        return patrao;
    }

    public void setPatrao(Humano patrao) {
        this.patrao = patrao;
    }

    public Humano getPai() {
        return pai;
    }

    public void setPai(Humano pai) {
        this.pai = pai;
    }

    public Humano getMae() {
        return mae;
    }

    public void setMae(Humano mae) {
        this.mae = mae;
    }

    public List<Comercio> getEmprego() {
        return emprego;
    }

    public void setEmprego(List<Comercio> emprego) {
        this.emprego = emprego;
    }

    // Construtor
    public Humano(String nome, int idade, String ocupacao) {
        super(nome, idade, new EstadoHumano(),true);
        this.ocupacao = ocupacao;

        
    }
    public void destruir(Mandinga mandinga){
        mandinga = null;
    }

}
