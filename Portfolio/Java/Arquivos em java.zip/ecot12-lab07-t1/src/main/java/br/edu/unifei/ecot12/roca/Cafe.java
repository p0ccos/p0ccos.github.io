package br.edu.unifei.ecot12.roca;

public class Cafe implements Producao {

    private int sacos;

    public int getSacos() {
        return sacos;
    }

    public void setSacos(int sacos) {
        this.sacos = sacos;
    }

    @Override
    public void atualizar(int dif) {
        sacos*=((100.0-dif)/100.0);
    }

    

}
