package br.edu.unifei.ecot12.lab10.clinica;

public class Main {

    public static void main(String[] args) {
        Consulta c = new Consulta();
        c.setSintomas("dor de cabeça");
        c.setTratamento("descançar");
        
        Historico h = new Historico();
        h.setConsulta(c);

        h.getProcedimentos().add(c.cria());//adiciona
        c.setTratamento("tomar doril");
        System.out.println(c.getTratamento());
        h.desfazer();
        System.out.println(c.getTratamento());

    }

}
