package br.edu.unifei.ecot12.fight;

public interface Golpe {

    public void bater();

}
