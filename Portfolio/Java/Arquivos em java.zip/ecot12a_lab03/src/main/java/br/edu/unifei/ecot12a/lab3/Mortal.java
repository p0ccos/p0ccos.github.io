package br.edu.unifei.ecot12a.lab3;

import java.util.Date;

public abstract class Mortal extends Ser{
    private Date dataNascimento;
    
    private Divindade hospedado;

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public Divindade getHospedado() {
        return hospedado;
    }

    public void setHospedado(Divindade hospedado) {
        this.hospedado = hospedado;
    }

    
}
