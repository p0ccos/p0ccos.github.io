package br.edu.unifei.ecot12a.lab3;

public class Alienigena extends Mortal{
    private String raca;

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    
}
