package br.edu.unifei.ecot12.trabalho;

public class Veiculo {
    private int numero;
    private String nome;
    private TipoEnum tipo;
    private int capacidadePassageiros;

    public int getNumero() {
        return numero;
    }
    public void setNumero(int numero) {
        this.numero = numero;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public TipoEnum getTipo() {
        return tipo;
    }
    public void setTipo(TipoEnum tipo) {
        this.tipo = tipo;
    }
    public int getCapacidadePassageiros() {
        return capacidadePassageiros;
    }
    public void setCapacidadePassageiros(int capacidadePassageiros) {
        this.capacidadePassageiros = capacidadePassageiros;
    }
    
    //Contrutor
    public Veiculo(int numero, String nome,TipoEnum tipo,int capacidadePassageiros){
        this.numero = numero;
        this.nome = nome;
        this.tipo = tipo;
        this.capacidadePassageiros = capacidadePassageiros;
    }
    

    
}
