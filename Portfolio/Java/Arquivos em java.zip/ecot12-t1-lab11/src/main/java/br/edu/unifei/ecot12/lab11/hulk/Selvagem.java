package br.edu.unifei.ecot12.lab11.hulk;

public class Selvagem implements Estado{

    private float resistencia;
    private float agilidade;
    private float regeneracao;
    @Override
    public void transformacao(Pessoa p) {
        if (p.getRaiva()<0.8) {
            p.setEstado(new Civilizado());
        }
    }
    public float getResistencia() {
        return resistencia;
    }
    public void setResistencia(float resistencia) {
        this.resistencia = resistencia;
    }
    public float getAgilidade() {
        return agilidade;
    }
    public void setAgilidade(float agilidade) {
        this.agilidade = agilidade;
    }
    public float getRegeneracao() {
        return regeneracao;
    }
    public void setRegeneracao(float regeneracao) {
        this.regeneracao = regeneracao;
    }
    
}
