package br.edu.unifei.ecot12.lab11.pagamento;

public interface Comando {
    public void executar();
}
