package br.edu.unifei.ecot12.spider;

public class Psiquico extends Poder {
	private int tempo;

	public int getTempo() {
		return tempo;
	}

	public void setTempo(int tempo) {
		this.tempo = tempo;
	}
	
}
