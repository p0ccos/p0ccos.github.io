package br.edu.unifei.ecot12.lab08.linguagem;

public interface Termo {
    

}
