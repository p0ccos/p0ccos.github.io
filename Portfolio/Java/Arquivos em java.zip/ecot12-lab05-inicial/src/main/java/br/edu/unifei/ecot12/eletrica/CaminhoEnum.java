package br.edu.unifei.ecot12.eletrica;

public enum CaminhoEnum {
    SERIE,
    PARALELO,
    MISTO
}
