package br.edu.unifei.ecot12.trabalho;

import java.util.ArrayList;
import java.util.List;

public abstract class Comercio {

    private String nome;
    private String endereco;
    private String turno;
    private List<Humano> clientes = new ArrayList<Humano>();
    private List<Humano> funcionario = new ArrayList<Humano>();
    private Lugar cidade;
    
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getEndereco() {
        return endereco;
    }
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    public String getTurno() {
        return turno;
    }
    public void setTurno(String turno) {
        this.turno = turno;
    }
    public List<Humano> getClientes() {
        return clientes;
    }
    public void setClientes(List<Humano> clientes) {
        this.clientes = clientes;
    }
    public List<Humano> getFuncionario() {
        return funcionario;
    }
    public void setFuncionario(List<Humano> funcionario) {
        this.funcionario = funcionario;
    }
    public Lugar getCidade() {
        return cidade;
    }
    public void setCidade(Lugar cidade) {
        this.cidade = cidade;
    }

    
    

}
