package br.edu.unifei.ecot12.lab09.salgado;

public abstract class Salgado {
    private RecheioEnum recheio;

    public RecheioEnum getRecheio() {
        return recheio;
    }

    public void setRecheio(RecheioEnum recheio) {
        this.recheio = recheio;
    }


}
