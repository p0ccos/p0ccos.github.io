package br.edu.unifei.ecot12.fringe;

public class Cientista extends Pessoa{

    private String mestrado;
    private String doutorado;
    private int publicacoes;
    private int fraudes;
    
    public Cientista(Universo universo) {
        super(universo);
    }

    public String getMestrado() {
        return mestrado;
    }

    public void setMestrado(String mestrado) {
        this.mestrado = mestrado;
    }

    public String getDoutorado() {
        return doutorado;
    }

    public void setDoutorado(String doutorado) {
        this.doutorado = doutorado;
    }

    public int getPublicacoes() {
        return publicacoes;
    }

    public void setPublicacoes(int publicacoes) {
        this.publicacoes = publicacoes;
    }

    public int getFraudes() {
        return fraudes;
    }

    public void setFraudes(int fraudes) {
        this.fraudes = fraudes;
    }

}
