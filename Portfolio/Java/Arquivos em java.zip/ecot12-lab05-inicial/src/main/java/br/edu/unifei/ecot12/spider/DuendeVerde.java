package br.edu.unifei.ecot12.spider;

import java.util.Date;

public class DuendeVerde extends Totem {
	private Date ingereSoro;
	private boolean modificado;
	public Date getIngereSoro() {
		return ingereSoro;
	}
	public void setIngereSoro(Date ingereSoro) {
		this.ingereSoro = ingereSoro;
	}
	public boolean isModificado() {
		return modificado;
	}
	public void setModificado(boolean modificado) {
		this.modificado = modificado;
	}
	
}
