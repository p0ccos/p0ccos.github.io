package br.edu.unifei.ecot12.lab01;

import java.util.Scanner;

public class Appp {
    public static void main(String[] args) {
        CampoMinado m = new CampoMinado();
        Scanner s = new Scanner(System.in);
        while(m.getFimJogo()==false){
            m.imprime();
            System.out.print("linha: ");
            int lin  = s.nextInt();
            System.out.print("coluna: ");
            int col = s.nextInt();
            m.totalDesarme(lin, col);
        
        }
        System.out.println("Fim de Jogo!");
        m.imprime();
        s.close();
    }
}