package br.edu.unifei.ecot12a.lab3;

public class Trouxa extends Humano{
    private boolean memoria;

    public boolean isMemoria() {
        return memoria;
    }

    public void setMemoria(boolean memoria) {
        this.memoria = memoria;
    }

    

}
