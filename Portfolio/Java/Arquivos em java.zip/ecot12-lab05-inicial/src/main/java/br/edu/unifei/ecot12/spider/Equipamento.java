package br.edu.unifei.ecot12.spider;

public class Equipamento {
	private String nome;
	private String uso;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getUso() {
		return uso;
	}
	public void setUso(String uso) {
		this.uso = uso;
	}
	
}
