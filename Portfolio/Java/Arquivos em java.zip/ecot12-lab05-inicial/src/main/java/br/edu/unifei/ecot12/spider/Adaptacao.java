package br.edu.unifei.ecot12.spider;

public class Adaptacao extends Poder {
	private int distancia;

	public int getDistancia() {
		return distancia;
	}

	public void setDistancia(int distancia) {
		this.distancia = distancia;
	}
	
}
