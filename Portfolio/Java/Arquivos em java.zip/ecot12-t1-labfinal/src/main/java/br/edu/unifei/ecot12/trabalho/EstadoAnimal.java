package br.edu.unifei.ecot12.trabalho;

public class EstadoAnimal implements EstadoSer{

    @Override
    public Ser transformaSer(Ser ser) {
        System.out.println(ser.getNome() + " voltou a ser Humano!");
        ser.setEstado(new EstadoHumano());
        Humano humano = new Humano(ser.getNome(), ser.getIdade(), null);
        return humano;

    }
    @Override
    public String toString() {
        return "sapo";
    }
}
