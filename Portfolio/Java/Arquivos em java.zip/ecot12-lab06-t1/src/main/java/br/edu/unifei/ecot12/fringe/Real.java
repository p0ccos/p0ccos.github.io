package br.edu.unifei.ecot12.fringe;

public class Real implements Universo{

    @Override
    public int vph(int idade) {
        return idade*77;
    }


}
