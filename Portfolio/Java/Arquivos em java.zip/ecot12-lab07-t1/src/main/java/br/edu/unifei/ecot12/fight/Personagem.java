package br.edu.unifei.ecot12.fight;

public abstract class Personagem {
    private Golpe golpe;

    public Golpe getGolpe() {
        return golpe;
    }

    public void setGolpe(Golpe golpe) {
        this.golpe = golpe;
    }

    public void chamarBater(){
        golpe.bater();
    }

}
