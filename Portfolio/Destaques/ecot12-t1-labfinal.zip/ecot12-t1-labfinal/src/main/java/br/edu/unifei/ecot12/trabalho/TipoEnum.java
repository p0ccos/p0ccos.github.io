package br.edu.unifei.ecot12.trabalho;

public enum TipoEnum {

    TERRESTRE,
    AQUATICO,
    AEREO

}
