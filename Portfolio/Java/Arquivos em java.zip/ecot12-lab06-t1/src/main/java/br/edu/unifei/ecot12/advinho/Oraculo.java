package br.edu.unifei.ecot12.advinho;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Oraculo {
    private Calendar fimMundo = new GregorianCalendar(2012,12,22);
    private boolean hojeChove;
    private static Oraculo unico = new Oraculo();
    public Calendar getFimMundo() {
        return fimMundo;
    }
    public void setFimMundo(Calendar fimMundo) {
        this.fimMundo = fimMundo;
    }
    public boolean isHojeChove() {
        return hojeChove;
    }
    public void setHojeChove(boolean hojeChove) {
        this.hojeChove = hojeChove;
    }
    private Oraculo(){}
    
    public static Oraculo getInstancia(){
        return unico;
    }

}
