# Laboratório de Metodologia Científica e Análise de Dados
# Guia 6
# Exercícios começam na linha 97

diabetes <- read.csv(file = "Downloads/diabetes.csv")

#Checando o carregamento dos dados
head(diabetes)


#Verificando o tipo de dados para cada classe
str(diabetes)

#Verificando os valores não preenchidos
#colSums soma os valores TRUE para as células e retorna onde não foi preenchido
colSums(is.na(diabetes))

#Análise Exploratória

#Analisando um resumo do conjunto de dados
summary(diabetes)

#Gráfico para uma visão geral dos dados
boxplot(diabetes)

#Filtrando pela classe Insulina
summary(diabetes$Insulin)

boxplot(diabetes$Insulin)

#Gerar histogramas para visualizar as relações de dados

hist(diabetes$Pregnancies)
hist(diabetes$BloodPressure)
hist(diabetes$SkinThickness)

hist(diabetes$Insulin)

#Com o histograma de insulina, percebe-se que já valores muito distantes da média
#Por isso vamos filtrar os valoes acima de 250

library(dplyr)

diabetes2 <- diabetes %>%
  filter(Insulin <= 250)


hist(diabetes2$Insulin)

boxplot(diabetes2)

#Alterando o tipo da coluna "Outcome" que é int para factor
diabetes2$Outcome <- as.factor(diabetes2$Outcome)

### CONSTRUÇÃO DO MODELO

install.packages("caTools")
library(caTools)

# Divisão dos dados em treino e teste - 70% dos dados para treino e 30% dos dados para teste
set.seed(123)
index = sample.split(diabetes2$Pregnancies, SplitRatio = .70)
index

#Categorização dos subconjuntos de treino e teste
train = subset(diabetes2, index == TRUE)
test = subset(diabetes2, index == FALSE)

#Verificação dos subconjuntos
dim(diabetes2)
dim(train)
dim(test)

install.packages("caret")
install.packages("e1071")

#Pacote que faz o treinamento de dados. Testar ?caret::train
library(caret)
library(e1071)

?caret::train

#Criação do primeiro modelo usando KNN
modelo <- train(Outcome ~., data = train, method = "knn", tuneGrid = expand.grid(k = c(1:20)) )

modelo$results
modelo$bestTune

plot(modelo)

modelo2 <- train(Outcome ~., data = train, method = "knn")
modelo2$results
modelo$bestTune

plot(modelo2)

#Exercício
#Faça modelos de treinamento para os algortimos Naive Bayes (naive_bayes), Random Forest (rpart2) e SVM (svmRadialSigma)
#Para o SVM, utilize a função predict() para avaliar o desempenho com dados não treinados
#Também para o SVM, crie uma confusionMatrix() para comparar os dados gerados com 
#os resultados esperados
#Crie um novo dataframe com dados de um novo paciente. Usando predict() indique se esse paciente
#seria diagnosticado como Positivo ou Negativo pelo seu modelo
#Faça um relatório comparando os resultados dos modelos e envie como resposta do LAB.