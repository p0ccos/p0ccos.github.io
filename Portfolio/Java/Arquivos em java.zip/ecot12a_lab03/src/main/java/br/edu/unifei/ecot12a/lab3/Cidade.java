package br.edu.unifei.ecot12a.lab3;

public class Cidade extends Territorio {
    private boolean geracaoEnergia;

    public boolean isGeracaoEnergia() {
        return geracaoEnergia;
    }

    public void setGeracaoEnergia(boolean geracaoEnergia) {
        this.geracaoEnergia = geracaoEnergia;
    }

}
