package br.edu.unifei.ecot12a.lab3;

public class Deus extends Divindade {
    private String designacao;

    public String getDesignacao() {
        return designacao;
    }

    public void setDesignacao(String designacao) {
        this.designacao = designacao;
    }

    
}
