package br.edu.unifei.ecot12.trabalho;

import java.util.ArrayList;
import java.util.List;

public abstract class Feitico{
    private List<Magia> magias = new ArrayList<Magia>();

    protected void notificar(String mensagem) {
        for (Magia obs : magias) {
            obs.atualizar(mensagem);
        }
    }

    public void aplicarTransformacao(Ser ser) {
        ser.realizarTransformacao();
        notificar(ser.getNome() + " foi transformado!");
    }

    public List<Magia> getMagias() {
        return magias;
    }

    public void setMagias(List<Magia> magias) {
        this.magias = magias;
    }

    public abstract void setStatus(String mensagem, Ser ser, boolean temSangue,Ser ser2);

    
}