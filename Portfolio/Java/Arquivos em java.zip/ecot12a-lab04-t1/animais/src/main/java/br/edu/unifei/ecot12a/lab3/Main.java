package br.edu.unifei.ecot12a.lab3;

public class Main {
    public static void main(String[] args) {
        Ministerio m = new Ministerio();
        m.setNome("Ministério da magia do Brasil");
        Fato f = new Fato(m);

        f.setDescricao("bloqueio do x");

        System.out.println(f.getMinisterio().getNome());




        
    }
}