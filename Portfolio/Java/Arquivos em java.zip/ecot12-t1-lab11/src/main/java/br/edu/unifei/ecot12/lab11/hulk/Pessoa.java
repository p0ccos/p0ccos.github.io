package br.edu.unifei.ecot12.lab11.hulk;

public class Pessoa {

    private String nome;
    private String profissao;
    private float raiva;
    private Estado estado = new Civilizado();
    public void avaliar(){
        estado.transformacao(this);
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getProfissao() {
        return profissao;
    }
    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }
    public float getRaiva() {
        return raiva;
    }
    public void setRaiva(float raiva) {
        this.raiva = raiva;
        avaliar();
    }
    public Estado getEstado() {
        return estado;
    }
    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    


}
