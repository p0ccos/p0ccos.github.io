package br.edu.unifei.ecot12a.lab3;

import java.util.ArrayList;
import java.util.List;

public class Reino {
    private String nome;
    private String simbolo;
    private List<Territorio> territorios = new ArrayList<Territorio>();
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getSimbolo() {
        return simbolo;
    }
    public void setSimbolo(String simbolo) {
        this.simbolo = simbolo;
    }
    public List<Territorio> getTerritorios() {
        return territorios;
    }
    public void setTerritorios(List<Territorio> territorios) {
        this.territorios = territorios;
    }
 
}
