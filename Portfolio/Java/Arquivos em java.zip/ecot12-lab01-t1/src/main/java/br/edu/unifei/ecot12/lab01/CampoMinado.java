package br.edu.unifei.ecot12.lab01;

import java.util.Random;

public class CampoMinado {
    private char gabarito[][] = new char[10][10];
    private char visual[][] = new char[10][10];
    public static final int TOTAL_BOMBAS = 10;
    private int totalDesarme;
    private boolean fimJogo;

    public CampoMinado(){

        for (int i = 0; i < TOTAL_BOMBAS; i++){
            for (int j = 0; j < TOTAL_BOMBAS; j++){
                gabarito[i][j] = ' ';
                visual[i][j] = '?';
            }
        }

        Random r = new Random();
        for (int i = 0; i < TOTAL_BOMBAS;i++){
            int l=r.nextInt(TOTAL_BOMBAS);
            int c=r.nextInt(TOTAL_BOMBAS);
            if(gabarito[l][c]=='*'){
                i--;
            }else{
                gabarito[l][c]='*';
            }    
        }
        for (int i = 0; i < TOTAL_BOMBAS; i++){
            for (int j = 0; j < TOTAL_BOMBAS; j++){
                if (gabarito[i][j]=='*'){
                    for (int di = -1; di <= 1; di++) {
                        for (int dj = -1; dj <= 1; dj++) {
                            int ni = i + di;
                            int nj = j + dj;
                            // Verifica se a nova posição está dentro dos limites do campo e não é uma bomba
                            if (ni >= 0 && ni < TOTAL_BOMBAS && nj >= 0 && nj < TOTAL_BOMBAS && gabarito[ni][nj] != '*') {
                                if (gabarito[ni][nj] == ' ') {
                                    gabarito[ni][nj] = '1';
                                } else {
                                    gabarito[ni][nj]++;
                                }
                            }
                        }
                    }                    
                   /* if(i==0){
                         if(j==0){
                            gabarito[i+1][j] = '1';
                            gabarito[i][j+1] = '1';
                            gabarito[i+1][j+1] = '1';
                        }else if(j==9){
                            gabarito[i+1][j] = '1';
                            gabarito[i][j-1] = '1';
                            gabarito[i+1][j-1] = '1';

                        }else{
                            gabarito[i][j-1] = '1';
                            gabarito[i+1][j-1] = '1';
                            gabarito[i+1][j] = '1';
                            gabarito[i][j+1] = '1';
                            gabarito[i+1][j+1] = '1';
                        }
                
                    }else if(i==9){
                        if(j==0){
                            gabarito[i-1][j] = '1';
                            gabarito[i-1][j+1] = '1';
                            gabarito[i][j+1] = '1';
                        }else if(j==9){
                            gabarito[i-1][j] = '1';
                            gabarito[i][j-1] = '1';
                            gabarito[i-1][j-1] = '1';

                        }else{
                            gabarito[i][j-1] = '1';
                            gabarito[i+1][j-1] = '1';
                            gabarito[i+1][j] = '1';
                            gabarito[i][j+1] = '1';
                            gabarito[i+1][j+1] = '1';
                        }
                    }else if(i>0&&i<9){
                        gabarito[i-1][j-1] = '1';
                        gabarito[i][j-1] = '1';
                        gabarito[i+1][j-1] = '1';
                        gabarito[i-1][j] = '1';
                        gabarito[i+1][j] = '1';
                        gabarito[i-1][j+1] = '1';
                        gabarito[i][j+1] = '1';
                        gabarito[i+1][j+1] = '1';
                        
                    } */
                }
            }
        }
    }
    public void totalDesarme(int l, int c){
        if(fimJogo==false&&visual[l][c]=='?'){
            visual[l][c] = gabarito[l][c];
            totalDesarme++;
            if(visual[l][c]=='*'){
                fimJogo = true;
            }
        }
    }
    public void imprime(){
        for (int i = 0; i < TOTAL_BOMBAS; i++){
            for (int j = 0; j < TOTAL_BOMBAS; j++){
                System.out.print("["+visual[i][j]+"]");
            }
            System.out.println();
        }
    }
    public int getTotalDesarme(){
        return totalDesarme;
    }

    public boolean getFimJogo(){
        return fimJogo;
    }
}
