package br.edu.unifei.ecot12.trabalho;

public class EstadoHumano implements EstadoSer{

    public void outroHumano(Ser ser1, Ser ser2, int nivelSangue){
        if(nivelSangue == 100){
            ser2.setNome(ser1.getNome());
        }else{
            ser2.setNome(ser2.getNome());
        }
    }

    @Override
    public Ser transformaSer(Ser ser) {

        if(ser.isVivo()){

        System.out.println(ser.getNome() + " está transformado em Sapo!");
        ser.setEstado(new EstadoAnimal());
        Sapo sapo = new Sapo(ser.getNome(), ser.getIdade());
        return sapo;

        }else{
            System.out.println(ser.getNome() + " está transformado em Sapo!");
            ser.setEstado(new EstadoSombra());
            Sombra sombra = new Sombra();
            return sombra;
        }
    }

    @Override
    public String toString() {
        return "humano";
    }
    

}
