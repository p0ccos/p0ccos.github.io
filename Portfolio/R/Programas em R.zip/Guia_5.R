# Laboratório de Metodologia Científica e Análise de Dados
# Guia 6 Poliana Cruz Costa
# Exercícios começam na linha 93

#Leitura da planilha de dados
viagens <- read.csv(
  file = "/home/aluno/Downloads/2019_Viagem2.csv", #importação do arquivo csv
  sep = ';', #definição do separador dos dados
  dec = ',' #definição da marcação do valor decimal
)

head(viagens)

View(viagens)

dim(viagens)

summary(viagens)

summary(viagens$Valor.passagens)

install.packages("dplyr")
library(dplyr)

glimpse(viagens)

?as.Date

viagens$data.inicio <- as.Date(viagens$Período...Data.de.início, "%d/%m/%Y")

glimpse(viagens)

viagens$data.inicio.formatada <- format(viagens$data.inicio, "%Y-%m")
viagens$data.inicio.formatada

glimpse(viagens)

hist(viagens$Valor.passagens) #Histograma dos valores de passagem

summary(viagens$Valor.passagens) 

boxplot(viagens$Valor.passagens) #Boxplot dos valores de passagem

sd(viagens$Valor.passagens) #Desvio Padrão

?colSums

colSums(is.na(viagens))

str(viagens$Situação)

table(viagens$Situação)

prop.table(table(viagens$Situação)) * 100

#Função de filtragem de limites dos valores de passagem
passagens_fitro <- viagens %>%
  select(Valor.passagens) %>%
  filter(Valor.passagens >= 200 & Valor.passagens <= 5000) 

hist(passagens_fitro$Valor.passagens) #Histograma valores filtrados

summary(viagens$Valor.passagens)

boxplot(passagens_fitro$Valor.passagens) #Boxplot valores filtrados



library(dplyr)


#Seleção de informações para criar gráfico de viagens por orgão
p1 <- viagens %>% 
  group_by(Nome.do.órgão.superior) %>%
  summarise(n = sum(Valor.passagens)) %>%
  arrange(desc(n)) %>%
  top_n(15)

#Alteração de nomes das colunas
names(p1) <- c("orgao", "valor")

p1
install.packages("ggplot2")
library(ggplot2)

#Criação do gráfico de barras de viagens por orgão
ggplot(p1, aes(x= reorder(orgao,valor), y = valor)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(x = "Valor", y="Orgaos")


#   Exercícios
#1)  Faça o gráfico de barras para encontrar os 20 destinos 
#    para os quais mais foram gastas passagens do conjunto de dados.
p2 <- viagens %>%
  group_by(Destinos)%>%
  summarise(n = sum(Valor.passagens))%>%
  top_n(20)
#Alteração de nomes das colunas
names(p2) <- c("destino", "valor")
  
#Criação do gráfico de barras de viagens por orgão
ggplot(p2, aes(x= reorder(destino,valor), y = valor)) +
  geom_bar(stat = "Identity", fill = "#1b5191") + 
  coord_flip() +
  labs(x = "Valor", y="Destinos")

#2)  Use o parâmetro fill para colorir as barras do gráfico. 
#    Ex: fill = "#0ba791"

#3)  Faça o gráfico para descobrir a quantidade de viagens por mês
#    O script desse gráfico está iniciado abaixo. Se preferir
#    fazer usando outra técnica, fique à vontade
library(dplyr)
p3  <- viagens %>%
  group_by(data.inicio.formatada) %>%
  summarise(qtd = n_distinct(Destinos))
  #Alteração de nomes das colunas
  names(p3) <- c("mes","qtd")

head(p3)

ggplot(p3, aes(x= mes, y = qtd)) +
  geom_bar(stat = "identity", fill = "#0ba791") +
  coord_flip()+
  labs(x ="Mês", y="Quantidade de viagens")

