package br.edu.unifei.ecot12.trabalho;

public class Borboleta extends Animal {

    private String corAsas;

    public String getCorAsas() {
        return corAsas;
    }

    public void setCorAsas(String corAsas) {
        this.corAsas = corAsas;
    }
    public Borboleta(String corAsas){
        super("borboleta", 0);
        this.corAsas = corAsas;
    }
    
}
