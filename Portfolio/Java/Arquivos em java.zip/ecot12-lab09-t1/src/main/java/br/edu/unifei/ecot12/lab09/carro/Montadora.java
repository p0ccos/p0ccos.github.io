package br.edu.unifei.ecot12.lab09.carro;

public class Montadora {
    private Segmento segmento;
    public Carro construir(){
        Carro c =new Carro();
        segmento.construirMotor(c);
        return c;
    }
    public Segmento getSegmento() {
        return segmento;
    }
    public void setSegmento(Segmento segmento) {
        this.segmento = segmento;
    }

    
    
}
