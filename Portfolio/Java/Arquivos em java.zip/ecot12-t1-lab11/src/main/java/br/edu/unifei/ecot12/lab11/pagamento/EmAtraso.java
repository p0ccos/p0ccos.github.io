package br.edu.unifei.ecot12.lab11.pagamento;

public class EmAtraso implements Comando {

    private Boleto boleto;

    public EmAtraso(Boleto boleto) {
        this.boleto = boleto;
    }

    @Override
    public void executar() {
       boleto.pagarEmAtraso();
    }

    public Boleto getBoleto() {
        return boleto;
    }

    public void setBoleto(Boleto boleto) {
        this.boleto = boleto;
    }
    

}
