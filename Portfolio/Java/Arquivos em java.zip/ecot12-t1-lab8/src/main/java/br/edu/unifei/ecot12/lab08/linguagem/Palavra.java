package br.edu.unifei.ecot12.lab08.linguagem;

public class Palavra implements Termo{

    private String caracteres;
    public String getCaracteres() {
        return caracteres;
    }
    public void setCaracteres(String caracteres) {
        this.caracteres = caracteres;
    }
    protected Palavra(){}
}
