package br.edu.unifei.ecot12.eletrica;

public class Main {
    public static void main(String[] args) {
        Circuito c111 = new Circuito();
        Circuito c112 = new Circuito();
        Componente c113 = new Componente();
        c113.setTipo(ComponenteEnum.RESISTOR);

        Circuito c11 = new Circuito();
        c11.getElementos().add(c111);
        c11.getElementos().add(c112);
        c11.getElementos().add(c113);

        Componente c12 = new Componente();
        c12.setTipo(ComponenteEnum.CAPACITOR);

        Circuito c1 = new Circuito();
        c1.getElementos().add(c11);
        c1.getElementos().add(c12);

        System.out.println(c1.totalElementos());
        System.out.println(c11.totalElementos());

    }

}
