package br.edu.unifei.ecot12.fringe;

public abstract class Pessoa {
    private String nome;
    private int idade;
    private String graduacao;
    private int qi;
    private Universo universo;

    private Pessoa pessoa;
    

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public Pessoa(Universo universo) {
        this.universo = universo;
    }

    public int incapacitacao() {
        return universo.vph(idade);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getGraduacao() {
        return graduacao;
    }

    public void setGraduacao(String graduacao) {
        this.graduacao = graduacao;
    }

    public int getQi() {
        return qi;
    }

    public void setQi(int qi) {
        this.qi = qi;
    }
}
