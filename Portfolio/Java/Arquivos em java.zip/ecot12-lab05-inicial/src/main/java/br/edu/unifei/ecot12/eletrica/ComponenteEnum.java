package br.edu.unifei.ecot12.eletrica;

public enum ComponenteEnum {

    RESISTOR,
    CAPACITOR,
    BOBINA,
    MEMRISTOR
}
