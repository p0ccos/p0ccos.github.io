package br.edu.unifei.ecot12.trabalho;

public class Transformacao extends Feitico {
    String status;

    public String getStatus() {
        return status;
    }

    @Override
    public void setStatus(String mensagem, Ser ser, boolean temSangue, Ser ser2) {
        if (temSangue) {
            if (mensagem != "sangue.") {
                mensagem = ser2.getNome() + " voltou a ser ele mesmo.";
                notificar(mensagem);
            } else {
                mensagem = ser2.getNome() + " está transformado em " + ser.getNome() + "!";
                notificar(mensagem);
                if (ser.getEstado() instanceof EstadoHumano) {
                    ser.realizarTransformacao(); // Realiza transformação
                }
            }
        } else {
            mensagem = ser2.getNome() + " voltou a ser ele mesmo.";
            notificar(mensagem);
        }
        status = mensagem;
    }

}
