package br.edu.unifei.ecot12.lab09.salgado;

public class Coxinha extends Salgado {

    private boolean temRequeijao;

    public boolean isTemRequeijao() {
        return temRequeijao;
    }

    public void setTemRequeijao(boolean temRequeijao) {
        this.temRequeijao = temRequeijao;
    }

    protected Coxinha(){}
}
