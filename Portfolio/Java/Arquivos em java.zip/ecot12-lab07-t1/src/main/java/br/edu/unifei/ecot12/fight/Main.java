package br.edu.unifei.ecot12.fight;

public class Main {
    public static void main(String[] args) {
        Hadouken h = new Hadouken();
        Shoryuken s = new Shoryuken();

        Ryu r = new Ryu();
        r.setGolpe(h);

        Ken k = new Ken();
        k.setGolpe(s);

        h.setKen(k);
        h.setRyu(r);
        s.setKen(k);
        s.setRyu(r);
        
        System.out.println(r.getVitalidade());
        System.out.println(k.getDano());

        r.hadouken();

        System.out.println(r.getVitalidade());
        System.out.println(k.getDano());
    }

}
