package br.edu.unifei.ecot12a.lab3;

public class Main {
    public static void main(String[] args) {
        Reino r = new Reino();
        r.setNome("Midgard");



        Cidade c = new Cidade();
        c.setNome("New York");
        c.setReino(r);
        r.getTerritorios().add(c);

        Divindade d = new Deus();
        d.setNome("Odin");
        d.setVivo(false);
        d.setSexo("masculino");


        Deus t = new Deus();
        t.setNome("Thor");
        t.setDesignacao("deus do trovão");
        t.setMora(c);
        t.setSexo("masculino");
        

        Ser f = new Deus();
        f.setNome("Freya");
        f.setVivo(false);
        f.;

        System.out.println(t.getMora().getReino().getNome());
        System.out.println(d.getNome());
        System.out.println(f.getNome());
    }

}