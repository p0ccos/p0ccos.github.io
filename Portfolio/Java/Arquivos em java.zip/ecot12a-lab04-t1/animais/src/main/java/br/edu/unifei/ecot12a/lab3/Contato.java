package br.edu.unifei.ecot12a.lab3;

public class Contato extends Feitico{
    

}
