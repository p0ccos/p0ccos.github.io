package br.edu.unifei.ecot12.spider;

public class Fisico extends Poder {
	private int peso;

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}
	
}
