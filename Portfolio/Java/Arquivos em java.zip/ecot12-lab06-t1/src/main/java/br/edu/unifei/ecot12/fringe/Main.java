package br.edu.unifei.ecot12.fringe;

public class Main {
    public static void main(String[] args) {
        
        Agente a = new Agente(new Alternativo());
        a.setNome("Astrid");
        a.setIdade(22);
        System.out.println(a.incapacitacao());
    }
}