package br.edu.unifei.ecot12.trabalho;

import java.util.ArrayList;
import java.util.List;

public class Cacar {
    private List<Ser> cacadores = new ArrayList<Ser>();
    private List<Ser> presa = new ArrayList<Ser>();

    public List<Ser> getCacadores() {
        return cacadores;
    }
    public void setCacadores(List<Ser> cacadores) {
        this.cacadores = cacadores;
    }
    public List<Ser> getPresa() {
        return presa;
    }
    public void setPresa(List<Ser> animais) {
        this.presa = animais;
    }
    public void captura(Ser presa, Ser cacador){
        presa.setLivre(false);
        System.out.println(presa.getNome()+" foi capturado por "+cacador.getNome()+".");
    }
    public void fuga(Ser presa){
        presa.setLivre(true);
        System.out.println(presa.getNome()+" está livre.");
    }
    public void desfaz(Ser presa,Sombra sombras, Humano alguem){
        if("feiticeiro".equals(alguem.getOcupacao())||"feiticeira".equals(alguem.getOcupacao())){
            sombras = null;
            fuga(presa);
            System.out.println(alguem.getNome()+" libertou "+presa.getNome()+".\n");
        }
    }
}
