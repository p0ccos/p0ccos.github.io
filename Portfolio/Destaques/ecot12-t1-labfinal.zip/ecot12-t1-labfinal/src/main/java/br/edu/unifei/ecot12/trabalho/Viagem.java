package br.edu.unifei.ecot12.trabalho;

import java.util.ArrayList;
import java.util.List;

public class Viagem {

    private int duracao;
    private Lugar origem;
    private Lugar destino;
    private List<Ser> passageiros = new ArrayList<Ser>();
    private Veiculo transporte;
    public int getDuracao() {
        return duracao;
    }
    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }
    public Lugar getOrigem() {
        return origem;
    }
    public void setOrigem(Lugar origem) {
        this.origem = origem;
    }
    public Lugar getDestino() {
        return destino;
    }
    public void setDestino(Lugar destino) {
        this.destino = destino;
    }
    public List<Ser> getPassageiros() {
        return passageiros;
    }
    public void setPassageiros(List<Ser> passageiros) {
        this.passageiros = passageiros;
    }
    public Veiculo getTransporte() {
        return transporte;
    }
    public void setTransporte(Veiculo transporte) {
        this.transporte = transporte;
    }
    
    public Viagem(int duracao, Lugar origem, Lugar destino, Veiculo transporte){
        this.duracao = duracao;
        this.origem = origem;
        this.destino = destino;
        this.transporte = transporte;
    }   

}
