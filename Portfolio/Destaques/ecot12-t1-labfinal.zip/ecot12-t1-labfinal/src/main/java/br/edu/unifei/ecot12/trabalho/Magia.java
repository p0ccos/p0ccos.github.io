package br.edu.unifei.ecot12.trabalho;

public abstract class Magia {

    private String nome;
    private String poder;
    private Humano feiticeiro, possui;
    
    public Humano getPossui() {
        return possui;
    }
    public void setPossui(Humano possui) {
        this.possui = possui;
    }
    public Humano getFeiticeiro() {
        return feiticeiro;
    }
    public void setFeiticeiro(Humano feiticeiro) {
        this.feiticeiro = feiticeiro;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getPoder() {
        return poder;
    }
    public void setPoder(String poder) {
        this.poder = poder;
    }
    
    public abstract void atualizar(String mensagem);

    public Magia(String poder){
        this.poder =poder;
    }
    

}
