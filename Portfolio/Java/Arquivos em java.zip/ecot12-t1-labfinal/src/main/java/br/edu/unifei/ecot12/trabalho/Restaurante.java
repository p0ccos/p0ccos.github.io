package br.edu.unifei.ecot12.trabalho;

public class Restaurante extends Comercio {

    private String refeicao;
    private boolean mesaReservada;
    
    public String getRefeicao() {
        return refeicao;
    }
    public void setRefeicao(String refeicao) {
        this.refeicao = refeicao;
    }
    public boolean isMesaReservada() {
        return mesaReservada;
    }
    public void setMesaReservada(boolean mesaReservada) {
        this.mesaReservada = mesaReservada;
    }

    

}
