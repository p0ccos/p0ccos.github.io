package br.edu.unifei.ecot12.spider;

import java.util.Scanner;

public class App {

	public static void main(String[] args) {
		TransformacaoAranha ta = new TransformacaoAranha();
		Scanner s = new Scanner(System.in);

		System.out.print("Digite o nome do humano: ");
		String a = s.nextLine();

		System.out.print("Digite o nome aranha: ");
		String b = s.nextLine();

		Evento e = ta.picadaAranha(a, b);
		Totem t = ((Humano) e.getSeres().get(0)).getTotem();

		for (Poder p : t.getPoderes()) {
			System.out.println(p.getNome());
		}

		s.close();
	}

}
