package br.edu.unifei.ecot12.eletrica;

import java.util.ArrayList;
import java.util.List;

public class Circuito extends Elementos {

    private CaminhoEnum caminho;
    private boolean aberto;
    private List<Elementos>elementos = new ArrayList<Elementos>();
      
    @Override
    public int totalElementos() {
        int soma=1;
        for(Elementos e: elementos){
            soma+=e.totalElementos();
        }
        return soma;
    }

    public CaminhoEnum getCaminho() {
        return caminho;
    }

    public void setCaminho(CaminhoEnum caminho) {
        this.caminho = caminho;
    }

    public boolean isAberto() {
        return aberto;
    }

    public void setAberto(boolean aberto) {
        this.aberto = aberto;
    }

    public List<Elementos> getElementos() {
        return elementos;
    }



    public void setElementos(List<Elementos> elementos) {
        this.elementos = elementos;
    }

}
