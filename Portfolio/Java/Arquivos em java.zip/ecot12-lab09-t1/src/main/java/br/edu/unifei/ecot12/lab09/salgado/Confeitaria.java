package br.edu.unifei.ecot12.lab09.salgado;

public interface Confeitaria <S extends Salgado>{
    public S novoSalgado();    
}