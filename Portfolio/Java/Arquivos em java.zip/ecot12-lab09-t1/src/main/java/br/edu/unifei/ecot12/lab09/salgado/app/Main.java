package br.edu.unifei.ecot12.lab09.salgado.app;

import br.edu.unifei.ecot12.lab09.salgado.Coxinha;
import br.edu.unifei.ecot12.lab09.salgado.Coxinharia;
import br.edu.unifei.ecot12.lab09.salgado.RecheioEnum;

public class Main {
    public static void main(String[] args) {
        //Coxinha c = new Coxinha();
        Coxinharia fab = new Coxinharia();
        Coxinha c = fab.novoSalgado();
        c.setRecheio(RecheioEnum.FRANGO);
        System.out.println(c.getRecheio());
    }

}
