package br.edu.unifei.ecot12.trabalho;

public class Imobiliaria extends Comercio {
    private String contrato;

    public String getContrato() {
        return contrato;
    }

    public void setContrato(String contrato) {
        this.contrato = contrato;
    }

    
}
