package br.edu.unifei.ecot12a.lab3;

public class Magica extends Planta {
    private String nucleoMagico;
    private String propriedade;
    private String  mobilidade;
    public String getNucleoMagico() {
        return nucleoMagico;
    }
    public void setNucleoMagico(String nucleoMagico) {
        this.nucleoMagico = nucleoMagico;
    }
    public String getPropriedade() {
        return propriedade;
    }
    public void setPropriedade(String propriedade) {
        this.propriedade = propriedade;
    }
    public String getMobilidade() {
        return mobilidade;
    }
    public void setMobilidade(String mobilidade) {
        this.mobilidade = mobilidade;
    }

    
}
