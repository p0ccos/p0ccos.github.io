package br.edu.unifei.ecot12.roca;

public class Main {
    public static void main(String[] args) {
        Cafe c = new Cafe();
        c.setSacos(100);
        Milho m = new Milho();
        m.setCaixas(100);
        Temperatura t = new Temperatura();
        t.setGraus(20);
        t.getProdutos().add(m);
        t.getProdutos().add(c);
        System.out.println(c.getSacos());
        System.out.println(m.getCaixas());
        t.setGraus(25);
        System.out.println(c.getSacos());
        System.out.println(m.getCaixas());


    }
}