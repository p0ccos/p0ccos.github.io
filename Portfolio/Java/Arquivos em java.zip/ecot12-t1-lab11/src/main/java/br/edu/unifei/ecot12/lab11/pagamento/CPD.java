package br.edu.unifei.ecot12.lab11.pagamento;

import java.util.ArrayList;
import java.util.List;

public class CPD{

    private List<Comando> comandos= new ArrayList<Comando>();
    
    public void processar(){
        for(Comando c:comandos){
            c.executar();
            System.out.println(c);
        }
    }

    public List<Comando> getComandos() {
        return comandos;
    }

    public void setComandos(List<Comando> comandos) {
        this.comandos = comandos;
    }
    

}
