package br.edu.unifei.ecot12a.lab3;

public class Protecao extends Feitico {
    private float alcance;

    public float getAlcance() {
        return alcance;
    }

    public void setAlcance(float alcance) {
        this.alcance = alcance;
    }

    

}
