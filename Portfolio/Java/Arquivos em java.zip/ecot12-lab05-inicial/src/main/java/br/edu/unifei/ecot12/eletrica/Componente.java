package br.edu.unifei.ecot12.eletrica;

public class Componente extends Elementos {

    private ComponenteEnum tipo;

    public ComponenteEnum getTipo() {
        return tipo;
    }

    public void setTipo(ComponenteEnum tipo) {
        this.tipo = tipo;
    }

    @Override
    public int totalElementos() {
        return 1;
    }
    
}
