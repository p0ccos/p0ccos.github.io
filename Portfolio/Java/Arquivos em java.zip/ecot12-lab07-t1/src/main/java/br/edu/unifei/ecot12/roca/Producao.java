package br.edu.unifei.ecot12.roca;

public interface Producao {

    public void atualizar(int dif);

}
