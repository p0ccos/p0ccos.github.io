package br.edu.unifei.ecot12.lab11.pagamento;

public class SemAtraso implements Comando {

    private Boleto boleto;
    
    public SemAtraso(Boleto boleto) {
        this.boleto = boleto;
    }

    @Override
    public void executar() {
        boleto.pagarSemAtraso();
    }

    public Boleto getBoleto() {
        return boleto;
    }

    public void setBoleto(Boleto boleto) {
        this.boleto = boleto;
    }
    


}
