package br.edu.unifei.ecot12.spider;

import java.util.Date;

public class Octopus extends Totem {
	private Date explosaoRadiotiva;

	public Date getExplosaoRadiotiva() {
		return explosaoRadiotiva;
	}

	public void setExplosaoRadiotiva(Date explosaoRadiotiva) {
		this.explosaoRadiotiva = explosaoRadiotiva;
	}	
	
}
