package br.edu.unifei.ecot12a.lab3;

public class NaoMagica extends Planta{
    private boolean fotossintese;

    public boolean isFotossintese() {
        return fotossintese;
    }

    public void setFotossintese(boolean fotossintese) {
        this.fotossintese = fotossintese;
    }

    
}
