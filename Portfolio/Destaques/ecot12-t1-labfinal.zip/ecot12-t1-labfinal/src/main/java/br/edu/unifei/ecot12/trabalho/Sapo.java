package br.edu.unifei.ecot12.trabalho;

public class Sapo extends Animal{

    private boolean muitoMuco;

    public boolean isMuitoMuco() {
        return muitoMuco;
    }

    public void setMuitoMuco(boolean muitoMuco) {
        this.muitoMuco = muitoMuco;
    }

    public Sapo(String nome, int idade){
        super(nome,idade);
    }
    
}
