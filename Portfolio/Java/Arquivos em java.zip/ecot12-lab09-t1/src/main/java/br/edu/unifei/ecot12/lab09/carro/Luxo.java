package br.edu.unifei.ecot12.lab09.carro;

public class Luxo implements Segmento {

    @Override
    public void construirMotor(Carro c) {
        
        c.getMotor().setCilindros(4);
        c.getMotor().setCombustivel("eletricidade");
        c.getMotor().setPotencia(2.0f); 

    }

}
