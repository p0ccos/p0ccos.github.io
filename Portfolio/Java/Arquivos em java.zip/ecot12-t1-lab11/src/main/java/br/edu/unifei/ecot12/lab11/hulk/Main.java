package br.edu.unifei.ecot12.lab11.hulk;

public class Main {
    public static void main(String[] args) {
        Pessoa p = new Pessoa();
        p.setNome("Bruce");
        System.out.println(p.getEstado());
        p.setRaiva(0.9f);
        System.out.println(p.getEstado());

    }
}