package br.edu.unifei.ecot12.trabalho;

public interface EstadoSer{

    public Ser transformaSer(Ser ser);
    
    
}
